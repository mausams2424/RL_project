"""
decision_engine.py
------------------
Layer 3: Decision Engine — Applies real-world constraints, risk guards,
and strategy-mode adjustments to raw RL agent actions before final execution.

Responsibilities:
  • Enforce max-allocation-per-asset cap
  • Enforce minimum cash reserve
  • Apply stop-loss override when drawdown exceeds threshold
  • Compute confidence score from model internals
  • Delegate action interpretation to caller or OutputLayer
  • Maintain a full audit trail of every constraint applied

Usage
-----
    engine = DecisionEngine(
        max_allocation=0.40,
        min_cash=0.05,
        stop_loss_threshold=0.15,
    )
    constrained_weights, audit = engine.apply_constraints(
        raw_weights=agent_output,
        portfolio_value=105000,
        peak_value=110000,
    )
"""

from __future__ import annotations

import numpy as np
import torch
import torch.nn.functional as F

from agents.dqn import DQNAgent
from agents.actor_critic import ActorCriticAgent
from agents.ppo import PPOAgent


# ─────────────────────────────────────────────────────────────────────────────
# Decision Engine
# ─────────────────────────────────────────────────────────────────────────────

class DecisionEngine:
    """
    Constraint-based decision engine that sits between the RL agent output
    and final portfolio execution.

    Parameters
    ----------
    max_allocation      : max fraction any single asset can receive (default 0.40)
    min_cash            : minimum fraction that must remain as cash (default 0.05)
    stop_loss_threshold : drawdown fraction that triggers defensive override (default 0.15)
    stop_loss_cash_target : fraction to shift into cash when stop-loss fires (default 0.80)
    risk_threshold      : annualised volatility above which risk alert fires (default 0.05)
    """

    def __init__(
        self,
        max_allocation: float = 0.40,
        min_cash: float = 0.05,
        stop_loss_threshold: float = 0.15,
        stop_loss_cash_target: float = 0.80,
        risk_threshold: float = 0.05,
    ):
        self.max_allocation = max_allocation
        self.min_cash = min_cash
        self.stop_loss_threshold = stop_loss_threshold
        self.stop_loss_cash_target = stop_loss_cash_target
        self.risk_threshold = risk_threshold

    # ------------------------------------------------------------------
    # Core constraint application
    # ------------------------------------------------------------------

    @staticmethod
    def _softmax(x: np.ndarray) -> np.ndarray:
        e = np.exp(x - np.max(x))
        return (e / (e.sum() + 1e-9)).astype(np.float32)

    @staticmethod
    def _renorm(weights: np.ndarray) -> np.ndarray:
        """Clip to [0,1] and renormalise to sum=1."""
        w = np.clip(weights, 0.0, 1.0)
        total = w.sum()
        return (w / (total + 1e-9)).astype(np.float32)

    def apply_constraints(
        self,
        raw_weights: np.ndarray,
        portfolio_value: float = 0.0,
        peak_value: float = 0.0,
        info: dict | None = None,
    ) -> tuple[np.ndarray, dict]:
        """
        Apply all risk-management constraints in sequence.

        Order of operations:
          1. Stop-loss override (most critical — fires first)
          2. Maximum allocation per asset cap
          3. Minimum cash reserve enforcement
          4. Final renormalisation

        Parameters
        ----------
        raw_weights     : weight vector in R^(n_assets+1); last element = cash
        portfolio_value : current portfolio dollar value
        peak_value      : highest portfolio value reached so far
        info            : optional env info dict (for pass-through metadata)

        Returns
        -------
        (constrained_weights, audit_trail)
        audit_trail: dict documenting which constraints fired and why
        """
        w = np.asarray(raw_weights, dtype=np.float64).copy()
        audit: dict = {
            "stop_loss_fired": False,
            "max_alloc_clipped": False,
            "min_cash_enforced": False,
            "constraints_applied": [],
        }

        # ── Drawdown calculation ───────────────────────────────────────────
        drawdown = 0.0
        if peak_value > 0 and portfolio_value > 0:
            drawdown = max(0.0, (peak_value - portfolio_value) / (peak_value + 1e-9))

        # ── 1. Stop-loss override ──────────────────────────────────────────
        if drawdown >= self.stop_loss_threshold:
            audit["stop_loss_fired"] = True
            audit["stop_loss_drawdown"] = round(drawdown, 4)
            audit["constraints_applied"].append(
                f"STOP-LOSS: drawdown {drawdown:.1%} ≥ threshold {self.stop_loss_threshold:.1%} "
                f"→ shifted to {self.stop_loss_cash_target:.0%} cash"
            )
            asset_allocation = 1.0 - self.stop_loss_cash_target
            n_assets = len(w) - 1
            if n_assets > 0:
                w[:-1] = asset_allocation / n_assets
            w[-1] = self.stop_loss_cash_target
            return self._renorm(w), audit

        # ── 2. Max-allocation-per-asset cap ───────────────────────────────
        asset_w = w[:-1]
        if np.any(asset_w > self.max_allocation):
            audit["max_alloc_clipped"] = True
            excess = np.clip(asset_w - self.max_allocation, 0, None)
            total_excess = excess.sum()
            asset_w = np.clip(asset_w, 0, self.max_allocation)
            # Redistribution: divide excess to cash
            w[:-1] = asset_w
            w[-1] += total_excess
            audit["constraints_applied"].append(
                f"MAX-ALLOC: clipped {total_excess:.1%} excess to cash "
                f"(cap={self.max_allocation:.0%})"
            )

        # ── 3. Minimum cash reserve ────────────────────────────────────────
        if w[-1] < self.min_cash:
            deficit = self.min_cash - w[-1]
            total_assets = w[:-1].sum()
            if total_assets > 1e-9:
                w[:-1] *= (total_assets - deficit) / total_assets
            w[-1] = self.min_cash
            audit["min_cash_enforced"] = True
            audit["constraints_applied"].append(
                f"MIN-CASH: enforced minimum {self.min_cash:.0%} cash reserve"
            )

        # ── 4. Final renormalisation ───────────────────────────────────────
        w = self._renorm(w)
        return w, audit

    # ------------------------------------------------------------------
    # Confidence scoring
    # ------------------------------------------------------------------

    def calculate_confidence(self, agent, state: np.ndarray) -> float:
        """
        Derive a 0-1 confidence score from the agent's internal distribution.

        DQN       : max softmax probability over Q-values
        A2C / PPO : inverse of policy std (high std = uncertain = low confidence)
        Others    : default 0.5
        """
        try:
            if isinstance(agent, DQNAgent):
                q_values = agent.get_q_values(state)
                probs = F.softmax(q_values, dim=1)
                return float(np.clip(probs.max().item(), 0.0, 1.0))

            elif isinstance(agent, (ActorCriticAgent, PPOAgent)):
                _, std, _ = agent.get_action_dist(state)
                avg_std = float(std.mean().item())
                return float(np.clip(1.0 / (1.0 + avg_std), 0.0, 1.0))

        except Exception:
            pass

        # Check if wrapped (StrategyWrapper)
        inner = getattr(agent, "agent", None)
        if inner is not None:
            return self.calculate_confidence(inner, state)

        return 0.5

    # ------------------------------------------------------------------
    # Risk alerting
    # ------------------------------------------------------------------

    def check_risk(self, recent_prices: np.ndarray) -> bool:
        """
        Return True if recent market volatility exceeds the risk threshold.

        Parameters
        ----------
        recent_prices : 2D array (T, n_assets) of close prices
        """
        if recent_prices is None or len(recent_prices) < 2:
            return False
        try:
            returns = np.diff(np.log(recent_prices + 1e-9), axis=0)
            volatility = float(np.std(returns))
            return volatility > self.risk_threshold
        except Exception:
            return False

    # ------------------------------------------------------------------
    # Action interpretation (BUY / SELL / HOLD labels)
    # ------------------------------------------------------------------

    @staticmethod
    def interpret_action(
        old_weights: np.ndarray,
        new_weights: np.ndarray,
        tickers: list[str],
        threshold: float = 0.02,
    ) -> list[dict]:
        """
        Compare old and new weights to generate labelled change records.

        Returns a list of dicts with keys:
            asset, weight, old_weight, action (BUY/SELL/HOLD), change
        """
        all_labels = tickers + ["CASH"]
        records = []
        for i, label in enumerate(all_labels):
            if i >= len(new_weights):
                continue
            new_w = float(new_weights[i])
            old_w = float(old_weights[i]) if i < len(old_weights) else 0.0
            diff = new_w - old_w
            if diff > threshold:
                action = "BUY"
            elif diff < -threshold:
                action = "SELL"
            else:
                action = "HOLD"
            records.append({
                "asset": label,
                "weight": new_w,
                "old_weight": old_w,
                "action": action,
                "change": diff,
            })
        return records

    # ------------------------------------------------------------------
    # Full recommendation pipeline (for AI Recommendations tab)
    # ------------------------------------------------------------------

    def get_recommendation(
        self,
        agent,
        state: np.ndarray,
        current_weights: np.ndarray,
        tickers: list[str],
        recent_prices: np.ndarray | None = None,
        portfolio_value: float = 0.0,
        peak_value: float = 0.0,
    ) -> dict:
        """
        Run a full forward pass: agent → constraints → audit → labels.

        Returns a structured recommendation dict compatible with the dashboard.
        """
        from agents.actor_critic import ActorCriticAgent
        from agents.ppo import PPOAgent

        # 1. Raw action from agent
        if isinstance(agent, (ActorCriticAgent, PPOAgent)):
            mean, _, _ = agent.get_action_dist(state)
            raw_weights = self._softmax(mean.squeeze(0).cpu().numpy())
        elif hasattr(agent, "agent"):  # StrategyWrapper
            raw_weights = agent.act(state)
            if isinstance(raw_weights, (int, np.integer)):
                raw_weights = np.ones(len(tickers) + 1) / (len(tickers) + 1)
        else:
            raw_weights = np.ones(len(tickers) + 1) / (len(tickers) + 1)

        # 2. Apply constraints
        constrained_weights, audit = self.apply_constraints(
            raw_weights, portfolio_value, peak_value
        )

        # 3. Confidence
        confidence = self.calculate_confidence(agent, state)

        # 4. Risk alert
        risk_alert = self.check_risk(recent_prices)

        # 5. Action labels
        recommendations = self.interpret_action(current_weights, constrained_weights, tickers)

        return {
            "weights": constrained_weights.tolist(),
            "raw_weights": raw_weights.tolist() if not isinstance(raw_weights, (int, np.integer)) else [],
            "confidence": confidence,
            "recommendations": recommendations,
            "risk_alert": risk_alert,
            "audit": audit,
            "drawdown": audit.get("stop_loss_drawdown", 0.0),
        }


def softmax(x: np.ndarray) -> np.ndarray:
    """Module-level softmax helper."""
    e_x = np.exp(x - np.max(x))
    return e_x / e_x.sum()
