"""
app.py
------
Streamlit dashboard — Advanced RL Portfolio Management System.
Powered by a 4-layer architecture: Environment → Agent → Decision Engine → Output Layer.

Run with:
    streamlit run app.py
"""

from __future__ import annotations

import sys
import os
import json
from pathlib import Path

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

import torch
torch.set_num_threads(1)
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import streamlit as st

from data.fetcher import get_close_prices
from data.preprocessor import DataPreprocessor
from envs.finance_env import FinanceEnv
from envs.wrappers import DiscreteActionWrapper
from agents.bandit import EpsilonGreedyBandit, UCBBandit
from agents.q_learning import QLearningAgent
from agents.sarsa import SARSAAgent
from agents.dqn import DQNAgent
from agents.actor_critic import ActorCriticAgent
from agents.ppo import PPOAgent
from agents.benchmarks import BuyAndHoldAgent, RandomAgent
from agents.strategy import StrategyMode, StrategyWrapper
from training.trainer import Trainer
from utils.metrics import compute_all_metrics, compute_benchmark_comparison
from decision_engine import DecisionEngine
from output_layer import OutputLayer


# ─────────────────────────────────────────────────────────────────────────────
# Page config
# ─────────────────────────────────────────────────────────────────────────────

st.set_page_config(
    page_title="RL Portfolio Intelligence",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ─────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

html, body, [class*="css"] { font-family: 'Inter', sans-serif; }

.main {
    background: linear-gradient(135deg, #0a0a1a 0%, #0d1b2a 50%, #0a1628 100%);
    min-height: 100vh;
}
section[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #0d1117 0%, #161b22 100%);
    border-right: 1px solid #21262d;
}
.metric-card {
    background: linear-gradient(135deg, rgba(22,33,62,0.9) 0%, rgba(15,23,42,0.9) 100%);
    border: 1px solid rgba(99,179,237,0.2);
    border-radius: 16px;
    padding: 20px;
    text-align: center;
    backdrop-filter: blur(10px);
    transition: border-color 0.3s ease, transform 0.2s ease;
}
.metric-card:hover {
    border-color: rgba(99,179,237,0.5);
    transform: translateY(-2px);
}
.metric-value {
    font-size: 2rem;
    font-weight: 700;
    background: linear-gradient(90deg, #63b3ed, #9f7aea);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}
.metric-label {
    font-size: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: #8b949e;
    margin-top: 4px;
}
.section-header {
    font-size: 1.25rem;
    font-weight: 600;
    color: #e6edf3;
    margin-bottom: 1rem;
    padding-bottom: 0.5rem;
    border-bottom: 1px solid #21262d;
}
.explain-card {
    background: linear-gradient(135deg, rgba(16,24,40,0.95), rgba(22,33,62,0.8));
    border: 1px solid rgba(99,179,237,0.15);
    border-left: 3px solid #63b3ed;
    border-radius: 12px;
    padding: 16px 20px;
    margin-bottom: 12px;
    font-size: 0.9rem;
    color: #c9d1d9;
    line-height: 1.7;
}
.action-buy  { color: #68d391; font-weight: 600; }
.action-sell { color: #fc8181; font-weight: 600; }
.action-hold { color: #f6ad55; font-weight: 600; }
.regime-bull { color: #68d391; }
.regime-bear { color: #fc8181; }
.regime-sideways { color: #f6ad55; }
.stButton > button {
    background: linear-gradient(90deg, #1a56db, #7c3aed);
    color: white;
    border: none;
    border-radius: 8px;
    padding: 0.6rem 2rem;
    font-weight: 600;
    letter-spacing: 0.03em;
    transition: opacity 0.2s ease;
    width: 100%;
}
.stButton > button:hover { opacity: 0.85; }
.audit-badge {
    display: inline-block;
    background: rgba(245,101,101,0.15);
    border: 1px solid rgba(245,101,101,0.4);
    border-radius: 6px;
    padding: 2px 10px;
    font-size: 0.75rem;
    color: #fc8181;
    margin: 2px;
}
.kpi-positive { color: #68d391; }
.kpi-negative { color: #fc8181; }
</style>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────────────────────────────────────

AGENT_NAMES = [
    "Epsilon-Greedy Bandit",
    "UCB Bandit",
    "Q-Learning",
    "SARSA",
    "DQN (Double)",
    "Actor-Critic (A2C)",
    "PPO",
]

DISCRETE_AGENTS = {"Epsilon-Greedy Bandit", "UCB Bandit", "Q-Learning", "SARSA", "DQN (Double)"}

COLOUR_MAP = {
    "Epsilon-Greedy Bandit": "#63b3ed",
    "UCB Bandit":            "#9f7aea",
    "Q-Learning":            "#f6ad55",
    "SARSA":                 "#68d391",
    "DQN (Double)":          "#fc8181",
    "Actor-Critic (A2C)":    "#f687b3",
    "PPO":                   "#4fd1c5",
    "Buy & Hold":            "#a0aec0",
    "Random":                "#e2e8f0",
}

BACKTEST_PRESETS = {
    "2018 Correction": ("2018-01-01", "2019-01-01"),
    "COVID Crash 2020": ("2020-01-01", "2020-12-31"),
    "Bull Run 2020–21": ("2020-04-01", "2021-12-31"),
    "Recent 2022–23": ("2022-01-01", "2023-12-31"),
    "Full 4Y 2020–24": ("2020-01-01", "2024-01-01"),
}


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _plotly_dark_layout(title: str = "") -> dict:
    return dict(
        title=dict(text=title, font=dict(color="#e6edf3", size=16)),
        paper_bgcolor="rgba(13,17,23,0.95)",
        plot_bgcolor="rgba(13,17,23,0.95)",
        font=dict(color="#8b949e", family="Inter"),
        xaxis=dict(gridcolor="#21262d", showgrid=True, zeroline=False, color="#8b949e"),
        yaxis=dict(gridcolor="#21262d", showgrid=True, zeroline=False, color="#8b949e"),
        legend=dict(bgcolor="rgba(22,27,34,0.8)", bordercolor="#30363d", borderwidth=1),
        margin=dict(l=20, r=20, t=50, b=20),
    )


@st.cache_data(show_spinner=False)
def cached_fetch(tickers: tuple, start: str, end: str) -> pd.DataFrame:
    return get_close_prices(list(tickers), start, end)


def build_env_and_data(
    tickers, start, end, window, lambda_vol, lambda_dd, lambda_tc,
    transaction_cost, max_allocation, min_cash_reserve, stop_loss_dd,
):
    close = cached_fetch(tuple(sorted(tickers)), start, end)
    downloaded = [t for t in tickers if t in close.columns]
    close = close[downloaded]

    prep = DataPreprocessor()
    features = prep.fit_transform(close)
    price_df = close.loc[prep.index]
    prices = price_df.values.astype(np.float32)

    env = FinanceEnv(
        features=features,
        prices=prices,
        window=window,
        tickers=downloaded,
        lambda_vol=lambda_vol,
        lambda_dd=lambda_dd,
        lambda_tc=lambda_tc,
        transaction_cost=transaction_cost,
        max_allocation=max_allocation,
        min_cash_reserve=min_cash_reserve,
        stop_loss_dd=stop_loss_dd,
    )
    return env, downloaded, close, prep.index


def build_agent(name: str, env: FinanceEnv, discrete_env: DiscreteActionWrapper, **hp):
    n_d = discrete_env.action_space.n
    obs_dim = env.observation_space.shape[0]
    n_cont = env.action_space.shape[0]

    if name == "Epsilon-Greedy Bandit":
        return EpsilonGreedyBandit(n_d, epsilon=hp.get("epsilon", 0.2))
    if name == "UCB Bandit":
        return UCBBandit(n_d, c=hp.get("ucb_c", 1.5))
    if name == "Q-Learning":
        return QLearningAgent(n_d, lr=hp.get("lr", 0.05), gamma=hp.get("gamma", 0.99))
    if name == "SARSA":
        return SARSAAgent(n_d, lr=hp.get("lr", 0.05), gamma=hp.get("gamma", 0.99))
    if name == "DQN (Double)":
        return DQNAgent(
            state_dim=obs_dim, n_actions=n_d,
            lr=hp.get("lr", 3e-4), gamma=hp.get("gamma", 0.99),
            batch_size=hp.get("batch_size", 128),
        )
    if name == "Actor-Critic (A2C)":
        return ActorCriticAgent(
            state_dim=obs_dim, action_dim=n_cont,
            lr_actor=hp.get("lr", 3e-4), gamma=hp.get("gamma", 0.99),
            entropy_coef=hp.get("entropy_coef", 0.01),
        )
    if name == "PPO":
        return PPOAgent(
            state_dim=obs_dim, action_dim=n_cont,
            lr=hp.get("lr", 3e-4), gamma=hp.get("gamma", 0.99),
        )
    raise ValueError(f"Unknown agent: {name}")


def smooth(values: list[float], k: int = 10) -> list[float]:
    if len(values) < k:
        return values
    return list(pd.Series(values).rolling(k, min_periods=1).mean())


def colour_action(label: str) -> str:
    mapping = {"BUY": "🟢 BUY", "SELL": "🔴 SELL", "HOLD": "🟡 HOLD"}
    return mapping.get(label, label)


def colour_regime(regime: str) -> str:
    mapping = {"Bull": "🟢 Bull", "Bear": "🔴 Bear", "Sideways": "🟡 Sideways"}
    return mapping.get(regime, regime)


# ─────────────────────────────────────────────────────────────────────────────
# Sidebar
# ─────────────────────────────────────────────────────────────────────────────

with st.sidebar:
    st.markdown("<h2 style='color:#e6edf3;margin-bottom:0'>⚙️ Configuration</h2>", unsafe_allow_html=True)
    st.markdown("---")

    st.markdown("**📊 Data Settings**")
    raw_tickers = st.text_input("Tickers (comma-separated)", value="AAPL, MSFT, GOOGL, AMZN",
                                help="Yahoo Finance-compatible symbols")
    tickers = [t.strip().upper() for t in raw_tickers.split(",") if t.strip()]

    col1, col2 = st.columns(2)
    with col1:
        start_date = st.date_input("Start Date", pd.Timestamp("2020-01-01"))
    with col2:
        end_date = st.date_input("End Date", pd.Timestamp("2024-01-01"))

    st.markdown("---")
    st.markdown("**🤖 Algorithm**")
    selected_agents = st.multiselect("Select Agent(s)", options=AGENT_NAMES,
                                     default=["DQN (Double)", "Actor-Critic (A2C)", "PPO"])

    st.markdown("---")
    st.markdown("**🧠 Training**")
    n_episodes = st.slider("Episodes", 10, 500, 100, 10)
    window = st.slider("Observation Window (days)", 5, 60, 20, 5)

    st.markdown("---")
    st.markdown("**⚖️ Reward Engineering**")
    lambda_vol = st.slider("λ1 Volatility Penalty", 0.0, 2.0, 0.5, 0.1)
    lambda_dd  = st.slider("λ2 Drawdown Penalty",   0.0, 2.0, 0.3, 0.1)
    lambda_tc  = st.slider("λ3 Transaction Cost",   0.0, 1.0, 0.2, 0.05)
    transaction_cost = st.slider("Base Transaction Cost (%)", 0.0, 1.0, 0.1, 0.05) / 100

    st.markdown("---")
    st.markdown("**🛡️ Risk Management**")
    max_alloc = st.slider("Max Allocation per Asset (%)", 10, 100, 40, 5) / 100
    min_cash  = st.slider("Min Cash Reserve (%)", 0, 30, 5, 1) / 100
    stop_loss = st.slider("Stop-Loss Drawdown (%)", 5, 50, 15, 5) / 100

    st.markdown("---")
    st.markdown("**🎯 Strategy Mode**")
    strategy_choice = st.selectbox("Applied to All Agents", ["Balanced", "Conservative", "Aggressive"])
    strategy_mode = StrategyMode(strategy_choice)

    include_benchmarks = st.checkbox("Include Buy & Hold + Random benchmarks", value=True)

    st.markdown("---")
    st.markdown("**🔧 Hyperparameters**")
    lr = st.select_slider("Learning Rate", options=[1e-4, 3e-4, 1e-3, 3e-3], value=3e-4)
    gamma = st.slider("Discount γ", 0.90, 0.999, 0.99, 0.001)

    st.markdown("")
    run_clicked = st.button("🚀 Train Agents")


# ─────────────────────────────────────────────────────────────────────────────
# Header
# ─────────────────────────────────────────────────────────────────────────────

st.markdown("""
<div style="text-align:center; padding: 2rem 0 1rem">
  <h1 style="
    font-size: 2.5rem; font-weight: 700;
    background: linear-gradient(90deg, #63b3ed, #9f7aea, #f687b3);
    -webkit-background-clip: text; -webkit-text-fill-color: transparent;
    margin-bottom: 0.25rem;"
  >
    🧠 RL Portfolio Intelligence
  </h1>
  <p style="color:#8b949e; font-size:1rem; margin:0">
    Explainable · Risk-Aware · Autonomous Financial Decision Engine
  </p>
</div>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# Pre-run state
# ─────────────────────────────────────────────────────────────────────────────

if not run_clicked:
    st.info("👈 Configure the settings in the sidebar and click **Train Agents** to start.")
    with st.expander("📖 About this Platform", expanded=True):
        cols = st.columns(4)
        items = [
            ("🏦", "Environment Layer", "Enhanced FinanceEnv with MACD, regime detection (Bull/Bear/Sideways), decomposed 3-term reward, and in-env risk guardrails."),
            ("🤖", "RL Agent Layer", "6 algorithms + new PPO. Strategy modes (Conservative/Balanced/Aggressive) wrap any agent for risk-profile adaptation."),
            ("⚙️", "Decision Engine", "Real-world constraints: max allocation per asset, minimum cash reserve, and stop-loss override at configurable drawdown."),
            ("🔍", "Output Layer", "Every step logged with human-readable NL explanation — WHY each BUY/SELL/HOLD was made using RSI, MACD, regime, drawdown signals."),
        ]
        for col, (icon, title, desc) in zip(cols, items):
            with col:
                st.markdown(f"""
                <div class='metric-card'>
                    <div style='font-size:2rem'>{icon}</div>
                    <div style='font-size:1rem;font-weight:600;color:#e6edf3;margin:8px 0 4px'>{title}</div>
                    <div style='font-size:0.8rem;color:#8b949e;line-height:1.5'>{desc}</div>
                </div>""", unsafe_allow_html=True)
    st.stop()


# ─────────────────────────────────────────────────────────────────────────────
# Training
# ─────────────────────────────────────────────────────────────────────────────

if not selected_agents:
    st.error("Please select at least one agent from the sidebar.")
    st.stop()

# ── Data loading ──────────────────────────────────────────────────────────
with st.spinner("⬇️ Fetching market data…"):
    try:
        env_base, downloaded_tickers, close_df, feat_index = build_env_and_data(
            tickers=tickers,
            start=str(start_date),
            end=str(end_date),
            window=window,
            lambda_vol=lambda_vol,
            lambda_dd=lambda_dd,
            lambda_tc=lambda_tc,
            transaction_cost=transaction_cost,
            max_allocation=max_alloc,
            min_cash_reserve=min_cash,
            stop_loss_dd=stop_loss,
        )
    except ValueError as ve:
        err_msg = str(ve)
        st.error(f"⚠️ {err_msg}")
        if "overlapping valid dates" in err_msg:
            st.info("💡 Try selecting more recent dates or fewer tickers.")
        elif "indicators" in err_msg or "sample(s)" in err_msg:
            st.info("💡 Try a wider date range (at least 2-3 months).")
        else:
            st.info("💡 Verify ticker symbols are correct (e.g., AAPL, BTC-USD).")
        st.stop()
    except Exception as e:
        st.error(f"Unexpected error: {e}")
        st.stop()

discrete_env = DiscreteActionWrapper(env_base)
n_obs = env_base.observation_space.shape[0]

st.success(f"✅ Loaded {len(feat_index)} trading days for: **{', '.join(downloaded_tickers)}**")
st.session_state.env_base = env_base
st.session_state.discrete_env = discrete_env
st.session_state.downloaded_tickers = downloaded_tickers
st.session_state.window = window
st.session_state.feat_index = feat_index
st.session_state.close_df = close_df
st.session_state.start_date = str(start_date)

# ── Shared Output Layer (last episode of last trained agent) ───────────────
shared_output_layer = OutputLayer(tickers=downloaded_tickers)
st.session_state.output_layer = shared_output_layer

# ── Decision Engine ────────────────────────────────────────────────────────
decision_engine = DecisionEngine(
    max_allocation=max_alloc,
    min_cash=min_cash,
    stop_loss_threshold=stop_loss,
)

# ── Train RL agents ────────────────────────────────────────────────────────
all_results: dict[str, list] = {}
hp = dict(lr=lr, gamma=gamma)

progress_bar = st.progress(0, text="Training…")
status_text = st.empty()
total_to_train = len(selected_agents) + (2 if include_benchmarks else 0)
trained_count = 0

for agent_name in selected_agents:
    status_text.text(f"🏋️ Training {agent_name} ({trained_count+1}/{total_to_train})…")
    use_discrete = agent_name in DISCRETE_AGENTS
    train_env = discrete_env if use_discrete else env_base

    raw_agent = build_agent(agent_name, env_base, discrete_env, **hp)
    # Apply strategy mode for continuous agents
    if strategy_mode != StrategyMode.BALANCED and agent_name not in DISCRETE_AGENTS:
        agent = StrategyWrapper(raw_agent, strategy_mode)
    else:
        agent = raw_agent

    # Use OutputLayer only for the last agent (captures final training state)
    ol = shared_output_layer if agent_name == selected_agents[-1] else None
    trainer = Trainer(train_env, agent, output_layer=ol, verbose=False,
                      strategy_mode=strategy_mode.value)
    records = trainer.train(n_episodes=n_episodes)

    all_results[agent_name] = records
    if "trained_agents" not in st.session_state:
        st.session_state.trained_agents = {}
    st.session_state.trained_agents[agent_name] = agent

    trained_count += 1
    progress_bar.progress(trained_count / total_to_train, text="Training…")

# ── Benchmark agents ───────────────────────────────────────────────────────
benchmark_results: dict[str, list] = {}
if include_benchmarks:
    for bench_name, BenchClass, kwargs in [
        ("Buy & Hold", BuyAndHoldAgent, {"n_actions": env_base.n_actions}),
        ("Random",     RandomAgent,     {"n_actions": env_base.n_actions, "seed": 42}),
    ]:
        status_text.text(f"📊 Running {bench_name} benchmark…")
        bench_agent = BenchClass(**kwargs)
        bench_trainer = Trainer(env_base, bench_agent, verbose=False)
        bench_records = bench_trainer.train(n_episodes=n_episodes)
        benchmark_results[bench_name] = bench_records
        trained_count += 1
        progress_bar.progress(trained_count / total_to_train, text="Training…")

st.session_state.benchmark_results = benchmark_results

status_text.empty()
progress_bar.empty()
st.success("🎉 Training complete!")


# ─────────────────────────────────────────────────────────────────────────────
# Dashboard Tabs
# ─────────────────────────────────────────────────────────────────────────────

tabs = st.tabs([
    "📈 Portfolio Performance",
    "🏆 Comparison",
    "💰 Allocation",
    "📉 Rewards & Loss",
    "🔍 Output Layer",
    "📊 Benchmarks",
    "⚙️ Strategy Modes",
    "🔬 Backtesting",
    "🤖 AI Recommendations",
])


# ─────────────────────────────────────────────────────────────────────────────
# TAB 1: Portfolio Performance
# ─────────────────────────────────────────────────────────────────────────────
with tabs[0]:
    st.markdown("<div class='section-header'>Portfolio Value Over Episodes</div>", unsafe_allow_html=True)

    fig = go.Figure()
    for agent_name, records in all_results.items():
        vals = [r.final_portfolio_value for r in records]
        smoothed = smooth(vals, k=max(1, n_episodes // 20))
        fig.add_trace(go.Scatter(
            x=list(range(len(smoothed))), y=smoothed, name=agent_name,
            line=dict(color=COLOUR_MAP.get(agent_name, "#fff"), width=2), mode="lines",
        ))
    fig.update_layout(**_plotly_dark_layout("Final Portfolio Value (Smoothed)"),
                      xaxis_title="Episode", yaxis_title="Portfolio Value ($)")
    st.plotly_chart(fig, use_container_width=True)

    st.markdown("<div class='section-header'>Best Episode Summary</div>", unsafe_allow_html=True)
    best_cols = st.columns(len(all_results))
    for col, (agent_name, records) in zip(best_cols, all_results.items()):
        best = max(records, key=lambda r: r.final_portfolio_value)
        with col:
            ret_color = "#68d391" if best.cumulative_return >= 0 else "#fc8181"
            st.markdown(f"""
            <div class='metric-card'>
                <div style='color:#8b949e;font-size:0.75rem;text-transform:uppercase'>{agent_name}</div>
                <div class='metric-value'>${best.final_portfolio_value:,.0f}</div>
                <div class='metric-label'>Best Portfolio Value</div>
                <div style='color:{ret_color};font-size:0.8rem;margin-top:4px'>
                    Ep {best.episode} · Ret {best.cumulative_return:+.1%}
                </div>
            </div>""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# TAB 2: Comparison Dashboard
# ─────────────────────────────────────────────────────────────────────────────
with tabs[1]:
    st.markdown("<div class='section-header'>Algorithm Comparison Metrics</div>", unsafe_allow_html=True)

    comparison_rows = []
    for agent_name, records in all_results.items():
        last = records[-1]
        avg_ret = np.mean([r.cumulative_return for r in records])
        avg_sharpe = np.mean([r.sharpe_ratio for r in records])
        avg_sortino = np.mean([r.sortino_ratio for r in records if r.sortino_ratio is not None])
        best_val = max(r.final_portfolio_value for r in records)
        comparison_rows.append({
            "Agent": agent_name,
            "Strategy": strategy_choice,
            "Avg Return": f"{avg_ret:+.2%}",
            "Avg Sharpe": f"{avg_sharpe:.3f}",
            "Avg Sortino": f"{avg_sortino:.3f}",
            "Last MDD": f"{last.max_drawdown:.2%}",
            "Last Portfolio ($)": f"${last.final_portfolio_value:,.0f}",
            "Best Portfolio ($)": f"${best_val:,.0f}",
        })
    st.dataframe(pd.DataFrame(comparison_rows).set_index("Agent"), use_container_width=True)

    if len(all_results) > 1:
        metrics_for_radar = ["Return", "Sharpe", "1-MDD"]
        categories = metrics_for_radar + [metrics_for_radar[0]]
        radar_fig = go.Figure()
        for agent_name, records in all_results.items():
            avg_ret_norm = float(np.clip(np.mean([r.cumulative_return for r in records]) + 0.5, 0, 1))
            avg_sharpe_norm = float(np.clip((np.mean([r.sharpe_ratio for r in records]) + 3) / 6, 0, 1))
            avg_mdd_inv = float(1 - np.mean([r.max_drawdown for r in records]))
            values = [avg_ret_norm, avg_sharpe_norm, avg_mdd_inv, avg_ret_norm]
            radar_fig.add_trace(go.Scatterpolar(
                r=values, theta=categories, fill="toself",
                name=agent_name, line=dict(color=COLOUR_MAP.get(agent_name, "#fff")), opacity=0.6,
            ))
        radar_fig.update_layout(
            polar=dict(radialaxis=dict(visible=True, range=[0, 1], color="#8b949e"),
                       bgcolor="rgba(13,17,23,0.95)"),
            paper_bgcolor="rgba(13,17,23,0.95)",
            font=dict(color="#8b949e", family="Inter"),
            legend=dict(bgcolor="rgba(22,27,34,0.8)", bordercolor="#30363d"),
            title=dict(text="Normalised Performance Radar", font=dict(color="#e6edf3")),
            margin=dict(l=40, r=40, t=60, b=40),
        )
        st.plotly_chart(radar_fig, use_container_width=True)

    bar_metric = st.selectbox("Bar chart metric",
        ["cumulative_return", "sharpe_ratio", "max_drawdown"],
        format_func=lambda x: x.replace("_", " ").title())
    bar_vals = {name: np.mean([getattr(r, bar_metric) for r in recs]) for name, recs in all_results.items()}
    bar_fig = go.Figure(go.Bar(
        x=list(bar_vals.keys()), y=list(bar_vals.values()),
        marker_color=[COLOUR_MAP.get(n, "#fff") for n in bar_vals.keys()],
        text=[f"{v:.3f}" for v in bar_vals.values()], textposition="auto",
    ))
    bar_fig.update_layout(**_plotly_dark_layout(f"Avg {bar_metric.replace('_',' ').title()} per Agent"),
                          xaxis_title="Agent", yaxis_title=bar_metric.replace("_", " ").title())
    st.plotly_chart(bar_fig, use_container_width=True)


# ─────────────────────────────────────────────────────────────────────────────
# TAB 3: Allocation
# ─────────────────────────────────────────────────────────────────────────────
with tabs[2]:
    st.markdown("<div class='section-header'>Portfolio Allocation Over Time (Last Episode)</div>",
                unsafe_allow_html=True)

    alloc_agent_name = st.selectbox("Select agent to inspect", list(all_results.keys()), key="alloc_select")
    if alloc_agent_name:
        use_discrete = alloc_agent_name in DISCRETE_AGENTS
        insp_env = discrete_env if use_discrete else env_base
        insp_agent = build_agent(alloc_agent_name, env_base, discrete_env, **hp)

        obs, _ = insp_env.reset()
        insp_agent.reset_episode()
        alloc_history, value_history = [], []
        dones = False
        while not dones:
            act = insp_agent.act(obs)
            obs, _, term, trunc, info = insp_env.step(act)
            dones = term or trunc
            if "weights" in info:
                alloc_history.append(info["weights"])
                value_history.append(info.get("portfolio_value", 0.0))

        if alloc_history:
            alloc_arr = np.array(alloc_history)
            alloc_labels = downloaded_tickers + ["Cash"]
            alloc_fig = go.Figure()
            for i, label in enumerate(alloc_labels):
                alloc_fig.add_trace(go.Scatter(
                    x=list(range(len(alloc_arr))), y=alloc_arr[:, i],
                    name=label, stackgroup="one", mode="lines",
                ))
            alloc_fig.update_layout(
                **_plotly_dark_layout(f"{alloc_agent_name} — Allocation Over Time"),
                xaxis_title="Step", yaxis_title="Weight",
                yaxis_range=[0, 1], yaxis_tickformat=".0%",
            )
            st.plotly_chart(alloc_fig, use_container_width=True)

            # Final allocation pie
            st.markdown("<div class='section-header'>Final Allocation Distribution</div>",
                        unsafe_allow_html=True)
            final_w = alloc_arr[-1]
            pie_fig = px.pie(values=final_w, names=alloc_labels, hole=0.4,
                             color_discrete_sequence=px.colors.qualitative.G10)
            pie_fig.update_layout(margin=dict(l=0, r=0, t=0, b=0),
                                  paper_bgcolor="rgba(0,0,0,0)",
                                  font=dict(color="#e6edf3", family="Inter"))
            st.plotly_chart(pie_fig, use_container_width=True)


# ─────────────────────────────────────────────────────────────────────────────
# TAB 4: Rewards & Loss
# ─────────────────────────────────────────────────────────────────────────────
with tabs[3]:
    st.markdown("<div class='section-header'>Reward Convergence</div>", unsafe_allow_html=True)
    rew_fig = go.Figure()
    for agent_name, records in all_results.items():
        rewards = smooth([r.total_reward for r in records], k=max(1, n_episodes // 15))
        rew_fig.add_trace(go.Scatter(
            x=list(range(len(rewards))), y=rewards, name=agent_name,
            line=dict(color=COLOUR_MAP.get(agent_name, "#fff"), width=2), mode="lines",
        ))
    rew_fig.update_layout(**_plotly_dark_layout("Training Reward Curve (Smoothed)"),
                          xaxis_title="Episode", yaxis_title="Total Reward")
    st.plotly_chart(rew_fig, use_container_width=True)

    loss_traces = [(name, recs) for name, recs in all_results.items()
                   if any(r.avg_loss is not None for r in recs)]
    if loss_traces:
        st.markdown("<div class='section-header'>Training Loss</div>", unsafe_allow_html=True)
        loss_fig = go.Figure()
        for agent_name, records in loss_traces:
            losses = [r.avg_loss for r in records if r.avg_loss is not None]
            smoothed_loss = smooth(losses, k=max(1, len(losses) // 15))
            loss_fig.add_trace(go.Scatter(
                x=list(range(len(smoothed_loss))), y=smoothed_loss, name=agent_name,
                line=dict(color=COLOUR_MAP.get(agent_name, "#fff"), width=2), mode="lines",
            ))
        loss_fig.update_layout(**_plotly_dark_layout("Avg Training Loss per Episode"),
                               xaxis_title="Episode", yaxis_title="Loss")
        st.plotly_chart(loss_fig, use_container_width=True)

    # Exploration vs Exploitation (DQN epsilon)
    dqn_agents = {n: a for n, a in st.session_state.get("trained_agents", {}).items()
                  if "DQN" in n}
    if dqn_agents:
        st.markdown("<div class='section-header'>Exploration vs Exploitation (ε)</div>",
                    unsafe_allow_html=True)
        eps_vals = {n: agent.epsilon if hasattr(agent, "epsilon")
                    else getattr(getattr(agent, "agent", agent), "epsilon", None)
                    for n, agent in dqn_agents.items()}
        eps_text = "  |  ".join(f"**{n}**: ε = {v:.4f}" for n, v in eps_vals.items() if v is not None)
        st.info(f"🎯 End-of-training epsilon: {eps_text}")

    st.markdown("<div class='section-header'>Historical Close Prices (Normalised)</div>",
                unsafe_allow_html=True)
    price_fig = go.Figure()
    for ticker in downloaded_tickers:
        if ticker in close_df.columns:
            norm = close_df[ticker] / close_df[ticker].iloc[0] * 100
            price_fig.add_trace(go.Scatter(x=close_df.index, y=norm, name=ticker, mode="lines"))
    price_fig.update_layout(**_plotly_dark_layout("Normalised Price (Base=100)"),
                            xaxis_title="Date", yaxis_title="Normalised Price")
    st.plotly_chart(price_fig, use_container_width=True)


# ─────────────────────────────────────────────────────────────────────────────
# TAB 5: Output Layer
# ─────────────────────────────────────────────────────────────────────────────
with tabs[4]:
    st.markdown("<div class='section-header'>🔍 Output Layer — Decision Intelligence Log</div>",
                unsafe_allow_html=True)

    ol: OutputLayer = st.session_state.get("output_layer")
    if ol is None or len(ol) == 0:
        st.warning("No Output Layer data available. Ensure a continuous-action agent (Actor-Critic, PPO) was trained.")
    else:
        summary = ol.get_episode_summary()
        state = ol.get_current_portfolio_state()

        # KPI row
        kpi_cols = st.columns(6)
        kpi_data = [
            ("Total Reward", f"{summary.get('total_reward', 0):+.4f}"),
            ("Final Value", f"${summary.get('final_portfolio_value', 0):,.0f}"),
            ("Total Return", f"{summary.get('total_return', 0):+.2%}"),
            ("Steps", str(summary.get("n_steps", 0))),
            ("Max Drawdown", f"{summary.get('max_drawdown', 0):.2%}"),
            ("Dominant Regime", summary.get("dominant_regime", "—")),
        ]
        for col, (label, val) in zip(kpi_cols, kpi_data):
            with col:
                st.markdown(f"""
                <div class='metric-card'>
                    <div class='metric-value' style='font-size:1.4rem'>{val}</div>
                    <div class='metric-label'>{label}</div>
                </div>""", unsafe_allow_html=True)

        st.markdown("")

        # Action counts
        col_a, col_b = st.columns(2)
        with col_a:
            st.markdown("<div class='section-header'>Action Distribution</div>", unsafe_allow_html=True)
            action_counts = {
                "BUY": summary.get("n_buys", 0),
                "SELL": summary.get("n_sells", 0),
                "HOLD": summary.get("n_holds", 0),
            }
            action_fig = go.Figure(go.Bar(
                x=list(action_counts.keys()),
                y=list(action_counts.values()),
                marker_color=["#68d391", "#fc8181", "#f6ad55"],
                text=list(action_counts.values()),
                textposition="auto",
            ))
            action_fig.update_layout(**_plotly_dark_layout("Action Counts"), height=300)
            st.plotly_chart(action_fig, use_container_width=True)

        with col_b:
            st.markdown("<div class='section-header'>Portfolio Value Trajectory</div>",
                        unsafe_allow_html=True)
            value_series = ol.get_portfolio_value_series()
            if value_series:
                val_fig = go.Figure(go.Scatter(
                    y=value_series, mode="lines",
                    line=dict(color="#63b3ed", width=2),
                    fill="tozeroy", fillcolor="rgba(99,179,237,0.1)",
                ))
                val_fig.update_layout(**_plotly_dark_layout(""), height=300)
                st.plotly_chart(val_fig, use_container_width=True)

        # Step history table
        st.markdown("<div class='section-header'>Step Decision Log</div>", unsafe_allow_html=True)
        hist_df = ol.get_history_df()
        if not hist_df.empty:
            # Show last 50 steps to keep it responsive
            display_df = hist_df.tail(50).reset_index(drop=True)
            st.dataframe(display_df, use_container_width=True, height=280)

        # Explanation cards (last 5 steps)
        st.markdown("<div class='section-header'>Latest Decision Explanations</div>",
                    unsafe_allow_html=True)
        history = ol.get_history()
        for record in reversed(history[-5:]):
            regime_icon = {"Bull": "🟢", "Bear": "🔴", "Sideways": "🟡"}.get(record.regime, "⚪")
            action_summary = " · ".join([
                f"<span class='action-{lbl.lower()}'>{t}: {lbl}</span>"
                for t, lbl in zip(record.tickers, record.action_labels)
            ])
            st.markdown(f"""
            <div class='explain-card'>
                <strong>Episode {record.episode} · Step {record.step}</strong>
                &nbsp;&nbsp;{regime_icon} <em>{record.regime}</em>
                &nbsp;&nbsp;💼 <strong>${record.portfolio_value:,.0f}</strong>
                &nbsp;&nbsp;📉 DD: {record.drawdown:.1%}
                <br/><small>{action_summary}</small>
                <hr style='border-color:#21262d;margin:8px 0'/>
                <div style='white-space:pre-line;font-size:0.85rem'>{record.explanation}</div>
            </div>""", unsafe_allow_html=True)

        # JSON export
        st.markdown("<div class='section-header'>Raw JSON Output (API-Ready)</div>",
                    unsafe_allow_html=True)
        with st.expander("View JSON"):
            # Show current state JSON (compact)
            st.code(json.dumps(state, indent=2), language="json")

        st.download_button(
            "⬇️ Download Full History JSON",
            data=ol.to_json(),
            file_name="output_layer_history.json",
            mime="application/json",
        )


# ─────────────────────────────────────────────────────────────────────────────
# TAB 6: Benchmarks
# ─────────────────────────────────────────────────────────────────────────────
with tabs[5]:
    st.markdown("<div class='section-header'>📊 RL vs Benchmark Comparison</div>",
                unsafe_allow_html=True)

    bench_results = st.session_state.get("benchmark_results", {})
    if not bench_results:
        st.info("Enable 'Include Buy & Hold + Random benchmarks' in the sidebar and re-train.")
    else:
        # Portfolio value comparison
        comp_fig = go.Figure()
        for agent_name, records in all_results.items():
            vals = smooth([r.final_portfolio_value for r in records], k=max(1, n_episodes // 20))
            comp_fig.add_trace(go.Scatter(
                x=list(range(len(vals))), y=vals, name=agent_name,
                line=dict(color=COLOUR_MAP.get(agent_name, "#fff"), width=2),
            ))
        for bench_name, records in bench_results.items():
            vals = smooth([r.final_portfolio_value for r in records], k=max(1, n_episodes // 20))
            comp_fig.add_trace(go.Scatter(
                x=list(range(len(vals))), y=vals, name=bench_name,
                line=dict(color=COLOUR_MAP.get(bench_name, "#ccc"), width=2, dash="dash"),
            ))
        comp_fig.update_layout(**_plotly_dark_layout("RL Agents vs Benchmarks — Portfolio Value"),
                               xaxis_title="Episode", yaxis_title="Portfolio Value ($)")
        st.plotly_chart(comp_fig, use_container_width=True)

        # Comparison table
        st.markdown("<div class='section-header'>Relative Performance vs Buy & Hold</div>",
                    unsafe_allow_html=True)

        bnh_records = bench_results.get("Buy & Hold", [])
        bnh_values = [r.final_portfolio_value for r in bnh_records] if bnh_records else []

        comparison_table = []
        for agent_name, records in {**all_results, **bench_results}.items():
            last_vals = [r.final_portfolio_value for r in records]
            if bnh_values and len(bnh_values) == len(last_vals):
                comp = compute_benchmark_comparison(last_vals, bnh_values)
                alpha = comp["alpha"]
                alpha_str = f"{alpha:+.2%}"
            else:
                alpha_str = "N/A"

            last = records[-1]
            comparison_table.append({
                "Agent": agent_name,
                "Type": "🤖 RL" if agent_name in all_results else "📊 Benchmark",
                "Final Return": f"{last.cumulative_return:+.2%}",
                "Sharpe": f"{last.sharpe_ratio:.3f}",
                "Max DD": f"{last.max_drawdown:.2%}",
                "Alpha vs B&H": alpha_str,
                "Final Value": f"${last.final_portfolio_value:,.0f}",
            })
        st.dataframe(pd.DataFrame(comparison_table).set_index("Agent"), use_container_width=True)

        # Return scatter: Sharpe vs Return
        scatter_fig = go.Figure()
        for agent_name, records in {**all_results, **bench_results}.items():
            avg_ret = np.mean([r.cumulative_return for r in records])
            avg_sharpe = np.mean([r.sharpe_ratio for r in records])
            avg_dd = np.mean([r.max_drawdown for r in records])
            is_bench = agent_name not in all_results
            scatter_fig.add_trace(go.Scatter(
                x=[avg_ret * 100], y=[avg_sharpe],
                mode="markers+text",
                marker=dict(
                    size=max(8, 30 - avg_dd * 100),
                    color=COLOUR_MAP.get(agent_name, "#fff"),
                    symbol="circle-open" if is_bench else "circle",
                    line=dict(width=2),
                ),
                text=[agent_name], textposition="top center",
                name=agent_name,
            ))
        scatter_fig.update_layout(
            **_plotly_dark_layout("Risk-Return Map (Bubble size ∝ 1/MDD)"),
            xaxis_title="Avg Cumulative Return (%)", yaxis_title="Avg Sharpe Ratio",
        )
        st.plotly_chart(scatter_fig, use_container_width=True)


# ─────────────────────────────────────────────────────────────────────────────
# TAB 7: Strategy Modes
# ─────────────────────────────────────────────────────────────────────────────
with tabs[6]:
    st.markdown("<div class='section-header'>⚙️ Strategy Mode Comparison</div>",
                unsafe_allow_html=True)

    continuous_agent_names = [n for n in selected_agents if n not in DISCRETE_AGENTS]
    if not continuous_agent_names:
        st.warning("Strategy modes apply to continuous-action agents (Actor-Critic, PPO). Add one in the sidebar.")
    else:
        strategy_agent_name = st.selectbox("Agent to compare across strategies",
                                           continuous_agent_names, key="strat_sel")

        if st.button("🔄 Run Strategy Comparison", key="strat_run"):
            use_env = env_base
            strategy_results = {}
            strat_prog = st.progress(0, "Running strategy modes…")

            for i, mode in enumerate([StrategyMode.CONSERVATIVE, StrategyMode.BALANCED, StrategyMode.AGGRESSIVE]):
                inner = build_agent(strategy_agent_name, env_base, discrete_env, **hp)
                wrapped = StrategyWrapper(inner, mode) if mode != StrategyMode.BALANCED else inner
                trainer = Trainer(use_env, wrapped, verbose=False, strategy_mode=mode.value)
                records = trainer.train(n_episodes=min(n_episodes, 50))
                strategy_results[mode.value] = records
                strat_prog.progress((i + 1) / 3, f"Running strategy modes…")

            strat_prog.empty()
            st.session_state.strategy_results = strategy_results
            st.session_state.strategy_agent = strategy_agent_name

        if "strategy_results" in st.session_state:
            strategy_results = st.session_state.strategy_results
            mode_colours = {"Conservative": "#68d391", "Balanced": "#63b3ed", "Aggressive": "#fc8181"}

            # Portfolio value comparison
            strat_fig = go.Figure()
            for mode_name, records in strategy_results.items():
                vals = smooth([r.final_portfolio_value for r in records], k=3)
                strat_fig.add_trace(go.Scatter(
                    x=list(range(len(vals))), y=vals, name=mode_name,
                    line=dict(color=mode_colours.get(mode_name, "#fff"), width=2),
                ))
            strat_fig.update_layout(
                **_plotly_dark_layout(f"{st.session_state.strategy_agent} — Strategy Mode Comparison"),
                xaxis_title="Episode", yaxis_title="Portfolio Value ($)",
            )
            st.plotly_chart(strat_fig, use_container_width=True)

            # Metrics table
            st.markdown("<div class='section-header'>Strategy Mode Metrics</div>",
                        unsafe_allow_html=True)
            mode_rows = []
            for mode_name, records in strategy_results.items():
                last = records[-1]
                mode_rows.append({
                    "Mode": mode_name,
                    "Avg Return": f"{np.mean([r.cumulative_return for r in records]):+.2%}",
                    "Avg Sharpe": f"{np.mean([r.sharpe_ratio for r in records]):.3f}",
                    "Avg Drawdown": f"{np.mean([r.max_drawdown for r in records]):.2%}",
                    "Final Value": f"${last.final_portfolio_value:,.0f}",
                })
            st.dataframe(pd.DataFrame(mode_rows).set_index("Mode"), use_container_width=True)

            # Sharpe vs Return scatter
            strat_scatter = go.Figure()
            for mode_name, records in strategy_results.items():
                avg_ret = np.mean([r.cumulative_return for r in records]) * 100
                avg_sharpe = np.mean([r.sharpe_ratio for r in records])
                strat_scatter.add_trace(go.Scatter(
                    x=[avg_ret], y=[avg_sharpe],
                    mode="markers+text",
                    marker=dict(size=18, color=mode_colours.get(mode_name, "#fff")),
                    text=[mode_name], textposition="top center", name=mode_name,
                ))
            strat_scatter.update_layout(
                **_plotly_dark_layout("Risk-Return by Strategy Mode"),
                xaxis_title="Avg Return (%)", yaxis_title="Avg Sharpe",
            )
            st.plotly_chart(strat_scatter, use_container_width=True)


# ─────────────────────────────────────────────────────────────────────────────
# TAB 8: Backtesting
# ─────────────────────────────────────────────────────────────────────────────
with tabs[7]:
    st.markdown("<div class='section-header'>🔬 Backtesting Engine</div>",
                unsafe_allow_html=True)

    bt_cols = st.columns([1, 1])
    with bt_cols[0]:
        bt_preset = st.selectbox("Historical period preset", ["Custom"] + list(BACKTEST_PRESETS.keys()))
    with bt_cols[1]:
        bt_agent_name = st.selectbox("Agent to backtest", list(all_results.keys()), key="bt_agent")

    if bt_preset != "Custom":
        bt_start, bt_end = BACKTEST_PRESETS[bt_preset]
    else:
        c1, c2 = st.columns(2)
        with c1:
            bt_start = str(st.date_input("Backtest Start", pd.Timestamp("2022-01-01"), key="bt_s"))
        with c2:
            bt_end = str(st.date_input("Backtest End", pd.Timestamp("2023-01-01"), key="bt_e"))

    bt_episodes = st.slider("Backtest Episodes", 5, 50, 10, 5, key="bt_ep")

    if st.button("▶️ Run Backtest", key="bt_run"):
        with st.spinner(f"Running backtest: {bt_preset} ({bt_start} → {bt_end})…"):
            try:
                bt_env, bt_tickers, bt_close, bt_index = build_env_and_data(
                    tickers=downloaded_tickers,
                    start=bt_start, end=bt_end,
                    window=window, lambda_vol=lambda_vol,
                    lambda_dd=lambda_dd, lambda_tc=lambda_tc,
                    transaction_cost=transaction_cost,
                    max_allocation=max_alloc, min_cash_reserve=min_cash,
                    stop_loss_dd=stop_loss,
                )
                bt_discrete = DiscreteActionWrapper(bt_env)
                use_discrete = bt_agent_name in DISCRETE_AGENTS
                bt_train_env = bt_discrete if use_discrete else bt_env

                bt_agent = build_agent(bt_agent_name, bt_env, bt_discrete, **hp)
                bt_trainer = Trainer(bt_train_env, bt_agent, verbose=False)
                bt_records = bt_trainer.train(n_episodes=bt_episodes)
                st.session_state.bt_records = bt_records
                st.session_state.bt_label = f"{bt_agent_name} / {bt_preset}"
                st.session_state.bt_close = bt_close
                st.session_state.bt_tickers = bt_tickers
                st.success(f"✅ Backtest complete: {len(bt_records)} episodes")
            except Exception as e:
                st.error(f"Backtest error: {e}")
                import traceback; st.code(traceback.format_exc())

    if "bt_records" in st.session_state:
        bt_records = st.session_state.bt_records
        bt_label = st.session_state.bt_label

        bt_vals = [r.final_portfolio_value for r in bt_records]
        bt_fig = go.Figure(go.Scatter(
            x=list(range(len(bt_vals))), y=bt_vals, mode="lines",
            line=dict(color="#9f7aea", width=2),
            fill="tozeroy", fillcolor="rgba(159,122,234,0.1)",
            name=bt_label,
        ))
        bt_fig.update_layout(**_plotly_dark_layout(f"Backtest: {bt_label}"),
                             xaxis_title="Episode", yaxis_title="Portfolio Value ($)")
        st.plotly_chart(bt_fig, use_container_width=True)

        # Metrics summary
        last_bt = bt_records[-1]
        bt_metric_cols = st.columns(5)
        bt_metrics = [
            ("Final Value", f"${last_bt.final_portfolio_value:,.0f}"),
            ("Cum. Return", f"{last_bt.cumulative_return:+.2%}"),
            ("Sharpe", f"{last_bt.sharpe_ratio:.3f}"),
            ("Max DD", f"{last_bt.max_drawdown:.2%}"),
            ("Steps/Ep", str(last_bt.n_steps)),
        ]
        for col, (label, val) in zip(bt_metric_cols, bt_metrics):
            with col:
                st.markdown(f"""
                <div class='metric-card'>
                    <div class='metric-value' style='font-size:1.4rem'>{val}</div>
                    <div class='metric-label'>{label}</div>
                </div>""", unsafe_allow_html=True)

        # Historical prices for this period
        bt_close = st.session_state.get("bt_close")
        if bt_close is not None:
            st.markdown("<div class='section-header'>Market Prices (Backtest Period)</div>",
                        unsafe_allow_html=True)
            price_fig2 = go.Figure()
            for ticker in st.session_state.get("bt_tickers", []):
                if ticker in bt_close.columns:
                    norm = bt_close[ticker] / bt_close[ticker].iloc[0] * 100
                    price_fig2.add_trace(go.Scatter(x=bt_close.index, y=norm, name=ticker, mode="lines"))
            price_fig2.update_layout(**_plotly_dark_layout("Normalised Price (Base=100)"),
                                     xaxis_title="Date", yaxis_title="Normalised Price")
            st.plotly_chart(price_fig2, use_container_width=True)


# ─────────────────────────────────────────────────────────────────────────────
# TAB 9: AI Recommendations
# ─────────────────────────────────────────────────────────────────────────────
with tabs[8]:
    st.markdown("<div class='section-header'>🤖 AI Decision Dashboard — Real-time Recommendation</div>",
                unsafe_allow_html=True)

    if "trained_agents" not in st.session_state or not st.session_state.trained_agents:
        st.warning("Please train at least one agent to see recommendations.")
    else:
        rec_agent_name = st.selectbox("Select Agent", list(st.session_state.trained_agents.keys()),
                                      key="rec_agent")

        if st.button("🚀 Get AI Recommendation", key="rec_btn"):
            engine = DecisionEngine(
                max_allocation=max_alloc,
                min_cash=min_cash,
                stop_loss_threshold=stop_loss,
            )
            agent = st.session_state.trained_agents[rec_agent_name]
            rec_ol = OutputLayer(tickers=downloaded_tickers)

            with st.spinner("🔍 Analysing latest market trends…"):
                today = pd.Timestamp.now().strftime("%Y-%m-%d")
                try:
                    latest_close = get_close_prices(
                        st.session_state.downloaded_tickers,
                        st.session_state.start_date, today
                    )
                    prep = DataPreprocessor()
                    latest_features = prep.fit_transform(latest_close)

                    if len(latest_features) < st.session_state.window:
                        st.error(f"Not enough data for {st.session_state.window}-day window.")
                    else:
                        s_feat = latest_features[-st.session_state.window:].flatten()
                        curr_weights = st.session_state.env_base._weights
                        state = np.concatenate([s_feat, curr_weights,
                                                np.array([0.0, 0.0, 1.0], dtype=np.float32)],
                                               dtype=np.float32)

                        # Get recommendation via decision engine
                        peak_val = float(st.session_state.env_base._peak_value)
                        port_val = float(st.session_state.env_base._portfolio_value)
                        recent_prices = latest_close.iloc[-st.session_state.window:].values

                        raw_inner = getattr(agent, "agent", agent)
                        rec_data = engine.get_recommendation(
                            raw_inner, state, curr_weights,
                            st.session_state.downloaded_tickers, recent_prices,
                            portfolio_value=port_val, peak_value=peak_val,
                        )

                        new_weights = np.array(rec_data["weights"])
                        confidence = rec_data["confidence"]
                        risk_alert = rec_data["risk_alert"]
                        audit = rec_data["audit"]

                        # Log to Output Layer for explainability
                        latest_env = st.session_state.env_base
                        state_features = {
                            "rsi_mean": 50.0,
                            "macd_signals": [],
                            "regime": "Sideways",
                            "volatility": 0.15,
                        }
                        try:
                            # Build temp env to get state features
                            last_row = latest_features[-1:]
                            n_feat = DataPreprocessor.N_FEATURES_PER_TICKER
                            n_tick = len(downloaded_tickers)
                            RSI_IDX, MACD_IDX = 3, 5
                            rsi_vals, macd_sigs = [], []
                            for i in range(n_tick):
                                base = i * n_feat
                                rsi_vals.append(float(last_row[0, base + RSI_IDX]) * 100 if base + RSI_IDX < last_row.shape[1] else 50.0)
                                if base + MACD_IDX < last_row.shape[1]:
                                    macd_sigs.append(float(last_row[0, base + MACD_IDX]))
                            state_features = {
                                "rsi_mean": float(np.mean(rsi_vals)),
                                "macd_signals": macd_sigs,
                                "regime": "Sideways",
                                "volatility": 0.15,
                            }
                        except Exception:
                            pass

                        step_record = rec_ol.log_step(
                            episode=0, step=0,
                            state_features=state_features,
                            raw_action=rec_data.get("raw_weights", new_weights.tolist()),
                            constrained_weights=new_weights.tolist(),
                            old_weights=curr_weights.tolist(),
                            reward=0.0,
                            portfolio_value=port_val,
                        )

                        # ── Display Results ──────────────────────────────────────
                        col1, col2 = st.columns([1, 2])
                        with col1:
                            st.markdown("<div class='section-header'>Suggested Allocation</div>",
                                        unsafe_allow_html=True)
                            pie_fig = px.pie(
                                values=new_weights,
                                names=downloaded_tickers + ["CASH"],
                                hole=0.4,
                                color_discrete_sequence=px.colors.qualitative.G10,
                            )
                            pie_fig.update_layout(
                                margin=dict(l=0, r=0, t=0, b=0),
                                paper_bgcolor="rgba(0,0,0,0)",
                                font=dict(color="#e6edf3", family="Inter"),
                                legend=dict(orientation="h", yanchor="bottom", y=-0.2, xanchor="center", x=0.5),
                            )
                            st.plotly_chart(pie_fig, use_container_width=True)

                            c_col = "#68d391" if confidence > 0.6 else "#f6ad55" if confidence > 0.4 else "#fc8181"
                            st.markdown(f"""
                            <div class='metric-card'>
                                <div class='metric-value' style='color:{c_col};font-size:1.6rem'>
                                    {confidence:.1%}
                                </div>
                                <div class='metric-label'>Model Confidence</div>
                            </div>""", unsafe_allow_html=True)

                            if risk_alert:
                                st.warning("⚠️ High Market Volatility — Risk-mitigation overrides applied.")

                            # Audit trail
                            if audit.get("constraints_applied"):
                                st.markdown("<div class='section-header'>Constraint Audit</div>",
                                            unsafe_allow_html=True)
                                for constraint in audit["constraints_applied"]:
                                    st.markdown(f"<span class='audit-badge'>{constraint}</span>",
                                                unsafe_allow_html=True)

                        with col2:
                            st.markdown("<div class='section-header'>Actionable Decisions</div>",
                                        unsafe_allow_html=True)
                            rec_df = pd.DataFrame(rec_data["recommendations"])
                            if not rec_df.empty:
                                display_df = rec_df[["asset", "weight", "old_weight", "action", "change"]].copy()
                                display_df["weight"] = display_df["weight"].map("{:.1%}".format)
                                display_df["old_weight"] = display_df["old_weight"].map("{:.1%}".format)
                                display_df["change"] = display_df["change"].map("{:+.1%}".format)
                                display_df.columns = ["Asset", "New Weight", "Old Weight", "Action", "Δ"]
                                st.dataframe(display_df.set_index("Asset"), use_container_width=True)

                            st.markdown("<div class='section-header'>AI Explanation</div>",
                                        unsafe_allow_html=True)
                            st.markdown(f"""
                            <div class='explain-card'>
                                {step_record.explanation}
                            </div>""", unsafe_allow_html=True)

                            # Summary insight
                            rec_df2 = rec_data["recommendations"]
                            top_buy = sorted([r for r in rec_df2 if r["action"] == "BUY"],
                                            key=lambda x: -x["change"])
                            top_sell = sorted([r for r in rec_df2 if r["action"] == "SELL"],
                                             key=lambda x: x["change"])
                            stance = "defensive 🛡️" if new_weights[-1] > 0.5 else "proactive 📈"
                            summary_txt = f"The **{rec_agent_name}** recommends a **{stance}** stance. "
                            if top_buy:
                                summary_txt += f"Largest reallocation **into {top_buy[0]['asset']}** (+{top_buy[0]['change']:.1%}). "
                            if top_sell:
                                summary_txt += f"Reducing exposure to **{top_sell[0]['asset']}** ({top_sell[0]['change']:.1%})."
                            st.info(f"💡 {summary_txt}")

                except Exception as e:
                    st.error(f"Error fetching latest data: {e}")
                    import traceback
                    st.code(traceback.format_exc())
