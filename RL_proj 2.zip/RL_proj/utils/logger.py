"""
utils/logger.py
----------------
Lightweight CSV + in-memory logger for training statistics.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class EpisodeRecord:
    episode: int
    agent: str
    total_reward: float
    final_portfolio_value: float
    cumulative_return: float
    sharpe_ratio: float
    max_drawdown: float
    n_steps: int
    avg_loss: float | None = None
    calmar_ratio: float | None = None
    sortino_ratio: float | None = None
    strategy_mode: str | None = None
    extra: dict = field(default_factory=dict)


class TrainingLogger:
    """Logs episode results to memory and optionally to a CSV file."""

    FIELDS = [
        "episode",
        "agent",
        "strategy_mode",
        "total_reward",
        "final_portfolio_value",
        "cumulative_return",
        "sharpe_ratio",
        "sortino_ratio",
        "max_drawdown",
        "calmar_ratio",
        "n_steps",
        "avg_loss",
    ]

    def __init__(self, log_dir: str | Path | None = None, agent_name: str = ""):
        self.records: list[EpisodeRecord] = []
        self.log_dir = Path(log_dir) if log_dir else None
        self._writer: csv.DictWriter | None = None
        self._file = None

        if self.log_dir:
            self.log_dir.mkdir(parents=True, exist_ok=True)
            fname = self.log_dir / f"{agent_name}_training.csv"
            self._file = open(fname, "w", newline="")
            self._writer = csv.DictWriter(self._file, fieldnames=self.FIELDS)
            self._writer.writeheader()

    def log(self, record: EpisodeRecord) -> None:
        self.records.append(record)
        if self._writer:
            row = {k: getattr(record, k, "") for k in self.FIELDS}
            self._writer.writerow(row)
            self._file.flush()

    def close(self) -> None:
        if self._file:
            self._file.close()

    # Convenience properties
    @property
    def rewards(self) -> list[float]:
        return [r.total_reward for r in self.records]

    @property
    def portfolio_values(self) -> list[float]:
        return [r.final_portfolio_value for r in self.records]
