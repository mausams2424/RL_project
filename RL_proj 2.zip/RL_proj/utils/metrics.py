"""
utils/metrics.py
-----------------
Financial performance metrics used to evaluate and compare RL agents.
Includes standard metrics (Sharpe, Drawdown, Calmar) and advanced metrics
(Sortino, Information Ratio, Benchmark Comparison).
"""

from __future__ import annotations

import numpy as np
import pandas as pd


def cumulative_return(portfolio_values: list[float] | np.ndarray) -> float:
    """Total return from start to end of episode."""
    values = np.asarray(portfolio_values, dtype=np.float64)
    if len(values) < 2 or values[0] == 0:
        return 0.0
    return float((values[-1] - values[0]) / values[0])


def sharpe_ratio(
    portfolio_values: list[float] | np.ndarray,
    risk_free_rate: float = 0.02,
    periods_per_year: int = 252,
) -> float:
    """Annualised Sharpe Ratio."""
    values = np.asarray(portfolio_values, dtype=np.float64)
    if len(values) < 2:
        return 0.0
    log_rets = np.diff(np.log(values + 1e-9))
    excess = log_rets - risk_free_rate / periods_per_year
    std = np.std(excess)
    if std < 1e-9:
        return 0.0
    return float(np.mean(excess) / std * np.sqrt(periods_per_year))


def sortino_ratio(
    portfolio_values: list[float] | np.ndarray,
    risk_free_rate: float = 0.02,
    periods_per_year: int = 252,
) -> float:
    """
    Annualised Sortino Ratio — uses only downside deviation in denominator.
    Penalises only negative return volatility, unlike Sharpe which penalises all.
    """
    values = np.asarray(portfolio_values, dtype=np.float64)
    if len(values) < 2:
        return 0.0
    log_rets = np.diff(np.log(values + 1e-9))
    excess = log_rets - risk_free_rate / periods_per_year
    downside = excess[excess < 0]
    if len(downside) == 0:
        return float(np.mean(excess) * np.sqrt(periods_per_year))
    downside_std = np.std(downside)
    if downside_std < 1e-9:
        return 0.0
    return float(np.mean(excess) / downside_std * np.sqrt(periods_per_year))


def max_drawdown(portfolio_values: list[float] | np.ndarray) -> float:
    """Maximum peak-to-trough drawdown (0 = no drawdown, 1 = full loss)."""
    values = np.asarray(portfolio_values, dtype=np.float64)
    if len(values) < 2:
        return 0.0
    peak = np.maximum.accumulate(values)
    drawdowns = (peak - values) / (peak + 1e-9)
    return float(np.max(drawdowns))


def calmar_ratio(
    portfolio_values: list[float] | np.ndarray,
    periods_per_year: int = 252,
) -> float:
    """Annualised return divided by maximum drawdown."""
    values = np.asarray(portfolio_values, dtype=np.float64)
    if len(values) < 2:
        return 0.0
    ann_return = cumulative_return(values) * (periods_per_year / len(values))
    mdd = max_drawdown(values)
    if mdd < 1e-9:
        return 0.0
    return float(ann_return / mdd)


def information_ratio(
    portfolio_values: list[float] | np.ndarray,
    benchmark_values: list[float] | np.ndarray,
    periods_per_year: int = 252,
) -> float:
    """
    Information Ratio — measures alpha relative to a benchmark, scaled by
    tracking error. A ratio > 0.5 is generally considered good.

    IR = mean(excess_return) / std(excess_return) * sqrt(periods_per_year)
    """
    p = np.asarray(portfolio_values, dtype=np.float64)
    b = np.asarray(benchmark_values, dtype=np.float64)

    # Align lengths
    n = min(len(p), len(b))
    if n < 2:
        return 0.0
    p, b = p[:n], b[:n]

    p_rets = np.diff(np.log(p + 1e-9))
    b_rets = np.diff(np.log(b + 1e-9))
    excess = p_rets - b_rets
    te = np.std(excess)
    if te < 1e-9:
        return 0.0
    return float(np.mean(excess) / te * np.sqrt(periods_per_year))


def compute_benchmark_comparison(
    agent_values: list[float] | np.ndarray,
    benchmark_values: list[float] | np.ndarray,
) -> dict[str, float]:
    """
    Compute relative performance metrics of agent vs a benchmark strategy.

    Returns
    -------
    dict with:
        agent_return, benchmark_return, alpha (excess return),
        information_ratio, agent_sharpe, benchmark_sharpe
    """
    a = np.asarray(agent_values, dtype=np.float64)
    b = np.asarray(benchmark_values, dtype=np.float64)

    return {
        "agent_return": cumulative_return(a),
        "benchmark_return": cumulative_return(b),
        "alpha": cumulative_return(a) - cumulative_return(b),
        "information_ratio": information_ratio(a, b),
        "agent_sharpe": sharpe_ratio(a),
        "benchmark_sharpe": sharpe_ratio(b),
        "agent_sortino": sortino_ratio(a),
        "agent_max_drawdown": max_drawdown(a),
        "benchmark_max_drawdown": max_drawdown(b),
    }


def compute_all_metrics(
    portfolio_values: list[float] | np.ndarray,
    risk_free_rate: float = 0.02,
    periods_per_year: int = 252,
) -> dict[str, float]:
    """Return a dict with all key performance indicators."""
    return {
        "cumulative_return": cumulative_return(portfolio_values),
        "sharpe_ratio": sharpe_ratio(portfolio_values, risk_free_rate, periods_per_year),
        "sortino_ratio": sortino_ratio(portfolio_values, risk_free_rate, periods_per_year),
        "max_drawdown": max_drawdown(portfolio_values),
        "calmar_ratio": calmar_ratio(portfolio_values, periods_per_year),
        "final_value": float(np.asarray(portfolio_values)[-1]),
    }
