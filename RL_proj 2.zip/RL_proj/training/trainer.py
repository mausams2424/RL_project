"""
training/trainer.py
--------------------
Unified, modular training loop that supports all RL agent types.
Integrates with the OutputLayer for step-level logging and explainability.

Usage
-----
    from training.trainer import Trainer
    results = Trainer(env, agent).train(n_episodes=200)

    # With OutputLayer
    ol = OutputLayer(tickers=["AAPL", "MSFT"])
    results = Trainer(env, agent, output_layer=ol).train(n_episodes=50)
"""

from __future__ import annotations

from typing import Any

import numpy as np
from tqdm import tqdm

from utils.metrics import compute_all_metrics
from utils.logger import EpisodeRecord, TrainingLogger


class Trainer:
    """
    Generic training loop compatible with all agent types.

    Discretised agents (MAB, Q-Learning, SARSA, DQN) must be used with a
    *wrapped* environment (DiscreteActionWrapper).
    Continuous agents (ActorCritic, PPO) should use the raw FinanceEnv.

    Parameters
    ----------
    env           : Gym-compatible environment (already wrapped if needed)
    agent         : Any BaseAgent subclass instance
    output_layer  : Optional OutputLayer — if provided, every step is logged
    log_dir       : directory to write CSV logs (None = no file logging)
    verbose       : if True, show episode progress bar
    strategy_mode : optional label for the strategy mode (for logging)
    """

    def __init__(
        self,
        env,
        agent,
        output_layer=None,
        log_dir: str | None = None,
        verbose: bool = True,
        strategy_mode: str | None = None,
    ):
        self.env = env
        self.agent = agent
        self.output_layer = output_layer
        self.logger = TrainingLogger(log_dir, agent_name=agent.name)
        self.verbose = verbose
        self.strategy_mode = strategy_mode

    # ------------------------------------------------------------------
    def _run_episode(self, episode_idx: int = 0) -> EpisodeRecord:
        """Run a single episode and return collected statistics."""
        obs, _ = self.env.reset()
        self.agent.reset_episode()

        # Reset OutputLayer for new episode
        if self.output_layer is not None:
            self.output_layer.reset(episode=episode_idx)

        total_reward = 0.0
        portfolio_history: list[float] = [self.env.unwrapped.initial_value]
        losses: list[float] = []

        # Track weights for OutputLayer logging
        prev_weights = self.env.unwrapped._weights.copy()

        done = False
        step = 0

        # SARSA needs to select action BEFORE the loop starts
        is_sarsa = self.agent.name == "SARSA"
        action = self.agent.act(obs) if is_sarsa else None

        while not done:
            if not is_sarsa:
                action = self.agent.act(obs)

            next_obs, reward, terminated, truncated, info = self.env.step(action)
            done = terminated or truncated

            # --- SARSA: pre-select next action ---
            next_action = None
            if is_sarsa:
                next_action = self.agent.act(next_obs)

            loss = self.agent.learn(
                obs,
                action,
                reward,
                next_obs,
                done,
                next_action=next_action,
            )

            if loss is not None:
                losses.append(float(loss))

            total_reward += reward
            portfolio_value = info.get("portfolio_value", self.env.unwrapped.initial_value)
            if "portfolio_value" in info:
                portfolio_history.append(portfolio_value)

            # ── Output Layer step logging ──────────────────────────────
            if self.output_layer is not None:
                new_weights = info.get(
                    "weights",
                    self.env.unwrapped._weights.tolist()
                )
                state_features = info.get("state_features", {})

                # Fallback state features if env doesn't provide them
                if not state_features:
                    try:
                        state_features = self.env.unwrapped.get_state_features_dict()
                    except Exception:
                        state_features = {"rsi_mean": 50.0, "macd_signals": [], "regime": "Sideways", "volatility": 0.15}

                self.output_layer.log_step(
                    episode=episode_idx,
                    step=step,
                    state_features=state_features,
                    raw_action=new_weights,   # For discrete agents, constrained = raw
                    constrained_weights=new_weights,
                    old_weights=prev_weights.tolist(),
                    reward=reward,
                    portfolio_value=portfolio_value,
                    raw_return=info.get("raw_return", 0.0),
                    risk_penalty=info.get("risk_penalty", 0.0),
                    metadata={
                        "drawdown": info.get("drawdown", 0.0),
                        "regime": info.get("regime", "Sideways"),
                        "stop_loss_flag": info.get("stop_loss_flag", False),
                    },
                )

            prev_weights = np.asarray(info.get("weights", prev_weights), dtype=np.float32)
            obs = next_obs
            if is_sarsa:
                action = next_action
            step += 1

        metrics = compute_all_metrics(portfolio_history)
        return EpisodeRecord(
            episode=0,                    # filled by caller
            agent=self.agent.name,
            strategy_mode=self.strategy_mode,
            total_reward=total_reward,
            final_portfolio_value=metrics["final_value"],
            cumulative_return=metrics["cumulative_return"],
            sharpe_ratio=metrics["sharpe_ratio"],
            sortino_ratio=metrics.get("sortino_ratio"),
            max_drawdown=metrics["max_drawdown"],
            calmar_ratio=metrics.get("calmar_ratio"),
            n_steps=step,
            avg_loss=float(np.mean(losses)) if losses else None,
        )

    # ------------------------------------------------------------------
    def train(
        self,
        n_episodes: int = 200,
        eval_interval: int = 10,
    ) -> list[EpisodeRecord]:
        """
        Train for *n_episodes* and return all episode records.

        Parameters
        ----------
        n_episodes    : total training episodes
        eval_interval : log to stdout every N episodes (if verbose)
        """
        all_records: list[EpisodeRecord] = []
        iterator = range(n_episodes)
        if self.verbose:
            iterator = tqdm(iterator, desc=f"Training {self.agent.name}")

        for ep in iterator:
            record = self._run_episode(episode_idx=ep)
            record.episode = ep
            self.logger.log(record)
            all_records.append(record)

            if self.verbose and (ep + 1) % eval_interval == 0:
                tqdm.write(
                    f"[Ep {ep+1:4d}]  Reward={record.total_reward:+.4f}  "
                    f"CumRet={record.cumulative_return:+.2%}  "
                    f"Sharpe={record.sharpe_ratio:.3f}  "
                    f"MDD={record.max_drawdown:.2%}"
                )

        self.logger.close()
        return all_records

    # ------------------------------------------------------------------
    @staticmethod
    def compare_agents(results: dict[str, list[EpisodeRecord]]) -> dict[str, dict]:
        """
        Summarise final-episode metrics for each agent.

        Parameters
        ----------
        results : {agent_name: [EpisodeRecord, …], …}

        Returns
        -------
        {agent_name: {metric: value, …}, …}
        """
        summary = {}
        for agent_name, records in results.items():
            if not records:
                continue
            last = records[-1]
            avg_reward = float(np.mean([r.total_reward for r in records[-20:]]))
            summary[agent_name] = {
                "avg_reward_last20": avg_reward,
                "cumulative_return": last.cumulative_return,
                "sharpe_ratio": last.sharpe_ratio,
                "sortino_ratio": last.sortino_ratio,
                "max_drawdown": last.max_drawdown,
                "calmar_ratio": last.calmar_ratio,
                "final_portfolio_value": last.final_portfolio_value,
            }
        return summary
