"""
data/fetcher.py
---------------
Downloads OHLCV data from Yahoo Finance and caches it locally.
"""

import yfinance as yf
import pandas as pd
import os
from pathlib import Path


CACHE_DIR = Path(__file__).parent / "cache"


def fetch_stock_data(
    tickers: list[str],
    start: str,
    end: str,
    interval: str = "1d",
    use_cache: bool = True,
) -> pd.DataFrame:
    """
    Download adjusted close prices (and volume) for the given tickers.

    Parameters
    ----------
    tickers   : list of ticker symbols, e.g. ['AAPL', 'MSFT', 'TSLA']
    start     : start date string 'YYYY-MM-DD'
    end       : end date string  'YYYY-MM-DD'
    interval  : yfinance interval string ('1d', '1h', …)
    use_cache : if True, read from / write to a local parquet cache

    Returns
    -------
    pd.DataFrame with MultiIndex columns (field, ticker) for Adj Close & Volume,
    and DatetimeIndex as rows.  Rows with any NaN are dropped.
    """
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    cache_key = "_".join(sorted(tickers)) + f"_{start}_{end}_{interval}"
    cache_file = CACHE_DIR / f"{cache_key}.parquet"

    if use_cache and cache_file.exists():
        df = pd.read_parquet(cache_file)
        if not df.empty:
            return df
        # If cache was somehow saved as empty, ignore it and re-fetch.
    raw = yf.download(
        tickers,
        start=start,
        end=end,
        interval=interval,
        auto_adjust=True,
        threads=True,
        progress=False,
    )

    if raw.empty:
        raise ValueError(f"No data found for tickers {tickers} from {start} to {end}")

    # Handle MultiIndex columns (Price, Ticker) pattern in newer yfinance
    if isinstance(raw.columns, pd.MultiIndex):
        # In newer versions, columns might be (Price, Ticker)
        # We want to extract 'Close' and 'Volume'
        close = raw["Close"]
        volume = raw["Volume"]
        
        # If single ticker, yfinance might return a Series. Force it to DataFrame.
        if isinstance(close, pd.Series):
            close = close.to_frame(name=tickers[0])
            volume = volume.to_frame(name=tickers[0])
    else:
        # Fallback for older versions or single-ticker simple Index
        close = raw[["Close"]].rename(columns={"Close": tickers[0]})
        volume = raw[["Volume"]].rename(columns={"Volume": tickers[0]})

    # Re-align columns to be consistent (Field, Ticker)
    df = pd.concat({"Close": close, "Volume": volume}, axis=1)
    
    # Check if we have any data at all before dropping NaNs
    if df.empty:
        raise ValueError(f"No valid data returned for tickers {tickers}. Check symbols and date range.")

    raw_len = len(df)
    df = df.dropna()
    
    if df.empty:
        raise ValueError(
            f"Data for tickers {tickers} has no overlapping valid dates in the range {start} to {end}. "
            f"(Started with {raw_len} days, but all contained missing values for at least one ticker)."
        )

    if use_cache:
        df.to_parquet(cache_file)

    return df


def get_close_prices(
    tickers: list[str],
    start: str,
    end: str,
    interval: str = "1d",
    use_cache: bool = True,
) -> pd.DataFrame:
    """Return a DataFrame of adjusted close prices only (columns = tickers)."""
    df = fetch_stock_data(tickers, start, end, interval, use_cache)
    return df["Close"]
