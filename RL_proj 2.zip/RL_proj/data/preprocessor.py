"""
data/preprocessor.py
---------------------
Computes technical indicators and normalises features ready for the RL environment.

Features per ticker (6 total):
    • log-return
    • SMA-10 / price   (ratio keeps it stationary)
    • SMA-30 / price
    • RSI-14  (already 0-100; scaled to 0-1)
    • Bollinger %B  (relative position between bands)
    • MACD signal   (12-day EMA − 26-day EMA, normalised by price)
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.preprocessing import RobustScaler


# ─────────────────────────────────────────────────────────────────────────────
# Technical indicators
# ─────────────────────────────────────────────────────────────────────────────

def compute_rsi(series: pd.Series, window: int = 14) -> pd.Series:
    """Relative Strength Index."""
    delta = series.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1 / window, min_periods=window, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1 / window, min_periods=window, adjust=False).mean()
    rs = avg_gain / (avg_loss + 1e-9)
    return 100 - 100 / (1 + rs)


def compute_sma(series: pd.Series, window: int) -> pd.Series:
    """Simple Moving Average."""
    return series.rolling(window, min_periods=window).mean()


def compute_ema(series: pd.Series, window: int) -> pd.Series:
    """Exponential Moving Average."""
    return series.ewm(span=window, adjust=False).mean()


def compute_bollinger_bands(
    series: pd.Series, window: int = 20, num_std: float = 2.0
) -> tuple[pd.Series, pd.Series, pd.Series]:
    """Returns (upper_band, middle_band, lower_band)."""
    mid = compute_sma(series, window)
    std = series.rolling(window).std()
    return mid + num_std * std, mid, mid - num_std * std


def compute_macd(
    series: pd.Series,
    fast: int = 12,
    slow: int = 26,
    signal: int = 9,
) -> tuple[pd.Series, pd.Series]:
    """
    MACD line and Signal line.

    Returns
    -------
    macd_line   : EMA(fast) − EMA(slow), normalised by price
    signal_line : 9-day EMA of macd_line
    """
    ema_fast = compute_ema(series, fast)
    ema_slow = compute_ema(series, slow)
    macd_line = (ema_fast - ema_slow) / (series + 1e-9)
    signal_line = macd_line.ewm(span=signal, adjust=False).mean()
    return macd_line, signal_line


# ─────────────────────────────────────────────────────────────────────────────
# DataPreprocessor
# ─────────────────────────────────────────────────────────────────────────────

class DataPreprocessor:
    """
    Builds a normalised feature matrix from raw close prices.

    Features per asset (after dropping NaN rows):
        0 log-return
        1 SMA-10 / price   (ratio keeps it stationary)
        2 SMA-30 / price
        3 RSI-14  (scaled 0–1)
        4 Bollinger %B  (relative position between bands)
        5 MACD signal line (normalised by price)
    """

    N_FEATURES_PER_TICKER: int = 6

    def __init__(self, sma_short: int = 10, sma_long: int = 30, rsi_window: int = 14):
        self.sma_short = sma_short
        self.sma_long = sma_long
        self.rsi_window = rsi_window
        self.scaler: RobustScaler | None = None
        self._n_features_per_ticker: int = self.N_FEATURES_PER_TICKER
        self._index: pd.DatetimeIndex | None = None
        self._columns: pd.Index | None = None

    # ------------------------------------------------------------------
    def _build_raw_features(self, close: pd.DataFrame) -> pd.DataFrame:
        """Return a DataFrame with columns [ticker_feature, …]."""
        frames = []
        for ticker in close.columns:
            s = close[ticker]

            log_ret = np.log(s / s.shift(1))
            sma_s = compute_sma(s, self.sma_short) / s
            sma_l = compute_sma(s, self.sma_long) / s
            rsi = compute_rsi(s, self.rsi_window) / 100.0

            upper, mid, lower = compute_bollinger_bands(s, 20)
            pct_b = (s - lower) / (upper - lower + 1e-9)

            _, macd_signal = compute_macd(s)

            feat = pd.DataFrame(
                {
                    f"{ticker}_logret": log_ret,
                    f"{ticker}_sma_short": sma_s,
                    f"{ticker}_sma_long": sma_l,
                    f"{ticker}_rsi": rsi,
                    f"{ticker}_pct_b": pct_b,
                    f"{ticker}_macd_signal": macd_signal,
                }
            )
            frames.append(feat)

        combined = pd.concat(frames, axis=1)
        return combined.dropna()

    # ------------------------------------------------------------------
    def fit_transform(self, close: pd.DataFrame) -> np.ndarray:
        """Fit scaler on *close* and return normalised feature array."""
        raw = self._build_raw_features(close)
        if raw.empty:
            raise ValueError(
                f"Not enough data to compute indicators. Data has {len(close)} rows, "
                f"but requires at least {self.sma_long + 1} days for the SMA-{self.sma_long} window."
            )
        self._index = raw.index
        self._columns = raw.columns
        self.scaler = RobustScaler()
        scaled = self.scaler.fit_transform(raw.values)
        # Clip extended outliers after robust scaling
        return np.clip(scaled, -5, 5).astype(np.float32)

    def transform(self, close: pd.DataFrame) -> np.ndarray:
        """Transform using already-fitted scaler."""
        if self.scaler is None:
            raise RuntimeError("Call fit_transform first.")
        raw = self._build_raw_features(close)
        if raw.empty:
            raise ValueError("Transform input results in empty features.")
        scaled = self.scaler.transform(raw.values)
        return np.clip(scaled, -5, 5).astype(np.float32)

    # ------------------------------------------------------------------
    @property
    def n_features_per_ticker(self) -> int:
        return self._n_features_per_ticker

    @property
    def index(self) -> pd.DatetimeIndex:
        return self._index
