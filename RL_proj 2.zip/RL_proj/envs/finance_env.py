"""
envs/finance_env.py
-------------------
Enhanced Gymnasium-compatible financial trading environment.

State  :  [window × n_tickers × n_features]  (flattened) +
          current portfolio weights (n_tickers + 1) +
          market_regime one-hot (3) : [bull, bear, sideways]

Action :  Continuous vector of length (n_tickers + 1)
          softmax → portfolio weights (including cash)

Reward :  Returns − λ1·Volatility − λ2·Drawdown − λ3·TransactionCost
          (fully decomposed, all components logged in info dict)

Risk guardrails applied inside step():
  - max_allocation per asset clipped before reward calculation
  - min_cash_reserve enforced before reward calculation
"""

from __future__ import annotations

import gymnasium as gym
import numpy as np
from gymnasium import spaces


class FinanceEnv(gym.Env):
    """
    Risk-aware portfolio allocation environment with enhanced state and reward.

    Parameters
    ----------
    features          : np.ndarray (T, n_tickers * n_features) — pre-scaled
    prices            : np.ndarray (T, n_tickers) — raw close prices
    window            : int — number of historical time-steps visible to agent
    tickers           : list[str] — ticker names for logging
    lambda_vol        : float — volatility penalty weight (λ1)
    lambda_dd         : float — drawdown penalty weight (λ2)
    lambda_tc         : float — transaction cost weight (λ3)
    risk_lambda       : float — legacy alias; maps to lambda_vol if given
    transaction_cost  : float — cost per unit weight change (proportional)
    initial_value     : float — starting portfolio value ($)
    max_allocation    : float — max fraction per single asset (default 1.0 = off)
    min_cash_reserve  : float — minimum cash fraction (default 0.0 = off)
    stop_loss_dd      : float — episode drawdown that triggers stop-loss flag in info
    regime_window     : int   — rolling window for market regime classification
    """

    metadata = {"render_modes": ["human"], "render_fps": 4}

    # Number of regime classes
    N_REGIME = 3  # [bull, bear, sideways]

    def __init__(
        self,
        features: np.ndarray,
        prices: np.ndarray,
        window: int = 20,
        tickers: list[str] | None = None,
        lambda_vol: float = 0.5,
        lambda_dd: float = 0.3,
        lambda_tc: float = 0.2,
        risk_lambda: float | None = None,   # legacy alias
        transaction_cost: float = 0.001,
        initial_value: float = 100_000.0,
        max_allocation: float = 1.0,
        min_cash_reserve: float = 0.0,
        stop_loss_dd: float = 0.25,
        regime_window: int = 20,
    ):
        super().__init__()

        assert features.shape[0] == prices.shape[0], (
            "features and prices must have the same number of rows"
        )

        self.features = features.astype(np.float32)
        self.prices = prices.astype(np.float32)
        self.window = window
        self.tickers = tickers or [f"Asset{i}" for i in range(prices.shape[1])]

        # Reward coefficients — support legacy risk_lambda
        self.lambda_vol = risk_lambda if risk_lambda is not None else lambda_vol
        self.lambda_dd = lambda_dd
        self.lambda_tc = lambda_tc

        self.transaction_cost = transaction_cost
        self.initial_value = initial_value
        self.max_allocation = max_allocation
        self.min_cash_reserve = min_cash_reserve
        self.stop_loss_dd = stop_loss_dd
        self.regime_window = regime_window

        self.n_assets = prices.shape[1]           # excludes cash
        self.n_actions = self.n_assets + 1        # assets + cash
        self.n_raw_features = features.shape[1]  # per timestep (flattened)

        # ── Observation space ─────────────────────────────────────────────
        # window * n_raw_features + n_actions (weights) + N_REGIME (one-hot)
        obs_dim = window * self.n_raw_features + self.n_actions + self.N_REGIME
        self.observation_space = spaces.Box(
            low=-np.inf, high=np.inf, shape=(obs_dim,), dtype=np.float32
        )
        # Raw action in R^n_actions; softmaxed internally → valid weights
        self.action_space = spaces.Box(
            low=-3.0, high=3.0, shape=(self.n_actions,), dtype=np.float32
        )

        # Episode state
        self._t: int = 0
        self._portfolio_value: float = 0.0
        self._peak_value: float = 0.0
        self._weights: np.ndarray = np.zeros(self.n_actions, dtype=np.float32)
        self._portfolio_history: list[float] = []
        self._episode_drawdown: float = 0.0

    # ──────────────────────────────────────────────────────────────────
    # Static Helpers
    # ──────────────────────────────────────────────────────────────────

    @staticmethod
    def _softmax(x: np.ndarray) -> np.ndarray:
        e = np.exp(x - np.max(x))
        return (e / (e.sum() + 1e-9)).astype(np.float32)

    # ──────────────────────────────────────────────────────────────────
    # Market Regime Detection
    # ──────────────────────────────────────────────────────────────────

    def _market_regime(self) -> tuple[str, np.ndarray]:
        """
        Classify current market regime using rolling returns and volatility.

        Returns
        -------
        regime_label : str — "Bull" | "Bear" | "Sideways"
        regime_onehot: np.ndarray shape (3,) — one-hot encoding [Bull, Bear, Sideways]
        """
        start = max(0, self._t - self.regime_window)
        if self._t <= start or self._t >= len(self.prices):
            return "Sideways", np.array([0.0, 0.0, 1.0], dtype=np.float32)

        segment = self.prices[start:self._t]
        if segment.shape[0] < 2:
            return "Sideways", np.array([0.0, 0.0, 1.0], dtype=np.float32)

        # Use mean asset log-return of the window
        log_rets = np.diff(np.log(segment + 1e-9), axis=0)
        mean_ret = float(np.mean(log_rets))
        vol = float(np.std(log_rets))

        # Classification thresholds
        BULL_THRESHOLD = 0.0005   # mean daily log-ret > 0.05%
        BEAR_THRESHOLD = -0.0005  # mean daily log-ret < -0.05%

        if mean_ret > BULL_THRESHOLD:
            return "Bull", np.array([1.0, 0.0, 0.0], dtype=np.float32)
        elif mean_ret < BEAR_THRESHOLD:
            return "Bear", np.array([0.0, 1.0, 0.0], dtype=np.float32)
        else:
            return "Sideways", np.array([0.0, 0.0, 1.0], dtype=np.float32)

    # ──────────────────────────────────────────────────────────────────
    # State & Reward
    # ──────────────────────────────────────────────────────────────────

    def _get_obs(self) -> np.ndarray:
        """Concatenate historical feature window + current weights + regime one-hot."""
        start = self._t - self.window
        window_feat = self.features[start: self._t].flatten()  # (window * n_raw,)
        _, regime_onehot = self._market_regime()
        return np.concatenate(
            [window_feat, self._weights, regime_onehot], dtype=np.float32
        )

    def _clamp_weights(self, weights: np.ndarray) -> np.ndarray:
        """
        Apply max-allocation and min-cash-reserve constraints to weight vector.
        Operates on a softmax-normalised weight vector.
        """
        w = weights.copy().astype(np.float64)

        # Max allocation per asset (excludes cash)
        if self.max_allocation < 1.0:
            clipped = np.clip(w[:-1], 0, self.max_allocation)
            excess = (w[:-1] - clipped).sum()
            w[:-1] = clipped
            w[-1] += excess  # redirect excess to cash

        # Min cash reserve
        if self.min_cash_reserve > 0 and w[-1] < self.min_cash_reserve:
            deficit = self.min_cash_reserve - w[-1]
            total_assets = w[:-1].sum()
            if total_assets > 1e-9:
                w[:-1] *= (total_assets - deficit) / total_assets
            w[-1] = self.min_cash_reserve

        # Renormalise
        total = w.sum()
        if total > 1e-9:
            w /= total
        return w.astype(np.float32)

    def _portfolio_return(self, old_w: np.ndarray, new_w: np.ndarray) -> float:
        """Log portfolio return from t-1 → t, minus transaction costs."""
        if self._t == 0:
            return 0.0
        price_prev = self.prices[self._t - 1]
        price_curr = self.prices[self._t]
        asset_returns = price_curr / (price_prev + 1e-9) - 1.0
        all_returns = np.append(asset_returns, 0.0)       # cash return = 0
        p_return = float(np.dot(old_w, all_returns))
        tc = self.transaction_cost * np.sum(np.abs(new_w - old_w))
        return p_return - tc

    def _compute_volatility(self) -> float:
        """Standard deviation of recent log-returns (from portfolio history)."""
        if len(self._portfolio_history) < 2:
            return 0.0
        hist = np.array(self._portfolio_history)
        log_rets = np.diff(np.log(hist + 1e-9))
        return float(np.std(log_rets)) if len(log_rets) > 1 else 0.0

    def _compute_drawdown(self) -> float:
        """Current maximum peak-to-trough drawdown in the episode."""
        if len(self._portfolio_history) < 2:
            return 0.0
        hist = np.array(self._portfolio_history)
        peak = np.maximum.accumulate(hist)
        drawdowns = (peak - hist) / (peak + 1e-9)
        return float(np.max(drawdowns))

    def _risk_penalty(self) -> tuple[float, float, float]:
        """
        Decomposed risk penalty.
        Returns (total_penalty, volatility_component, drawdown_component).
        """
        vol = self._compute_volatility()
        dd = self._compute_drawdown()
        total = self.lambda_vol * vol + self.lambda_dd * dd
        return total, vol, dd

    # ──────────────────────────────────────────────────────────────────
    # State feature extraction helpers (for Output Layer / explainability)
    # ──────────────────────────────────────────────────────────────────

    def get_state_features_dict(self) -> dict:
        """
        Return a structured dict of current market indicators for the OutputLayer.

        Keys: rsi_mean, macd_signals, regime, volatility
        """
        start = max(0, self._t - self.window)
        feat_slice = self.features[start: self._t]   # (window, n_raw_features)

        n_tickers = self.n_assets
        n_feat_per_ticker = self.n_raw_features // n_tickers if n_tickers > 0 else 1

        # Feature index positions (matches preprocessor order):
        # 0=logret, 1=sma_short, 2=sma_long, 3=rsi, 4=pct_b, 5=macd_signal
        RSI_IDX = 3
        MACD_IDX = 5  # index 5 = macd_signal

        rsi_values = []
        macd_signals = []

        if feat_slice.shape[0] > 0 and n_feat_per_ticker > 0:
            last_row = feat_slice[-1]  # most recent timestep features
            for i in range(n_tickers):
                base = i * n_feat_per_ticker
                if base + RSI_IDX < len(last_row):
                    # RSI was scaled 0-1 in preprocessor; convert back to 0-100 approx
                    rsi_values.append(float(last_row[base + RSI_IDX]) * 100)
                if n_feat_per_ticker > MACD_IDX and base + MACD_IDX < len(last_row):
                    macd_signals.append(float(last_row[base + MACD_IDX]))

        regime_label, _ = self._market_regime()
        volatility = self._compute_volatility() * np.sqrt(252)  # annualise

        return {
            "rsi_mean": float(np.mean(rsi_values)) if rsi_values else 50.0,
            "macd_signals": macd_signals,
            "regime": regime_label,
            "volatility": float(volatility),
        }

    # ──────────────────────────────────────────────────────────────────
    # Gym API
    # ──────────────────────────────────────────────────────────────────

    def reset(
        self,
        *,
        seed: int | None = None,
        options: dict | None = None,
    ) -> tuple[np.ndarray, dict]:
        super().reset(seed=seed)
        self._t = self.window          # first valid step
        self._portfolio_value = self.initial_value
        self._peak_value = self.initial_value
        # Start fully in cash
        self._weights = np.zeros(self.n_actions, dtype=np.float32)
        self._weights[-1] = 1.0
        self._portfolio_history = [self._portfolio_value]
        self._episode_drawdown = 0.0
        return self._get_obs(), {}

    def step(
        self, action: np.ndarray
    ) -> tuple[np.ndarray, float, bool, bool, dict]:
        assert self._t < len(self.features), "Environment is done; call reset()."

        old_weights = self._weights.copy()

        # Softmax raw action → valid weights
        new_weights = self._softmax(action)

        # Apply in-environment guardrails (max_allocation, min_cash)
        new_weights = self._clamp_weights(new_weights)
        self._weights = new_weights

        # Portfolio return (raw, before risk penalty)
        p_ret = self._portfolio_return(old_weights, new_weights)
        self._portfolio_value *= 1.0 + p_ret
        self._peak_value = max(self._peak_value, self._portfolio_value)
        self._portfolio_history.append(self._portfolio_value)

        # Decomposed risk penalty
        current_dd = max(
            0.0,
            (self._peak_value - self._portfolio_value) / (self._peak_value + 1e-9)
        )
        self._episode_drawdown = max(self._episode_drawdown, current_dd)

        risk_penalty, vol_component, dd_component = self._risk_penalty()
        tc_component = self.transaction_cost * float(np.sum(np.abs(new_weights - old_weights)))

        # Full decomposed reward
        reward = float(p_ret - self.lambda_vol * vol_component
                       - self.lambda_dd * dd_component
                       - self.lambda_tc * tc_component)

        self._t += 1
        terminated = self._t >= len(self.features)

        obs = self._get_obs() if not terminated else np.zeros(
            self.observation_space.shape, dtype=np.float32
        )

        regime_label, _ = self._market_regime()

        info = {
            "portfolio_value": self._portfolio_value,
            "weights": new_weights.tolist(),
            "raw_return": p_ret,
            "risk_penalty": risk_penalty,
            "vol_component": vol_component,
            "dd_component": dd_component,
            "tc_component": tc_component,
            "drawdown": current_dd,
            "peak_value": self._peak_value,
            "episode_max_drawdown": self._episode_drawdown,
            "regime": regime_label,
            "stop_loss_flag": current_dd >= self.stop_loss_dd,
            "state_features": self.get_state_features_dict(),
        }
        return obs, reward, terminated, False, info

    def render(self) -> None:
        w_str = ", ".join(
            f"{t}:{w:.2%}" for t, w in zip(self.tickers + ["Cash"], self._weights)
        )
        regime_label, _ = self._market_regime()
        print(
            f"[t={self._t:4d}]  Value=${self._portfolio_value:>12,.2f} "
            f"Regime={regime_label}  |  {w_str}"
        )

    def close(self) -> None:
        pass
