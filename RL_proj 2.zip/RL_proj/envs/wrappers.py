"""
envs/wrappers.py
-----------------
Gymnasium wrappers to adapt the continuous FinanceEnv for discrete algorithms
(MAB, Q-Learning, SARSA, DQN).
"""

from __future__ import annotations

import numpy as np
import gymnasium as gym
from gymnasium import spaces


class DiscreteActionWrapper(gym.Wrapper):
    """
    Wraps FinanceEnv with a *discrete* action space.

    Each discrete action corresponds to a pre-defined allocation template,
    e.g. "go 100% AAPL", "equal-weight all", "100% cash", etc.

    The templates are automatically generated to cover:
      - 100% in each single asset
      - 100% cash
      - Equal-weight across all assets
      - 50% in each pair of assets (if n_assets > 1)

    Parameters
    ----------
    env : FinanceEnv
    """

    def __init__(self, env: gym.Env):
        super().__init__(env)
        n = env.n_actions  # n_assets + 1 (cash)

        # Build discrete action templates
        templates = []
        # All-in on each asset or all-in cash
        for i in range(n):
            w = np.zeros(n, dtype=np.float32)
            w[i] = 3.0          # will be softmaxed inside env
            templates.append(w)
        # Equal-weight across assets (cash=0)
        ew = np.ones(n - 1, dtype=np.float32)
        templates.append(
            np.concatenate([ew / max(1, n - 1) * 2.0, [0.0]])
        )
        # Equal-weight ALL (assets + cash)
        templates.append(np.ones(n, dtype=np.float32))

        self._templates = np.array(templates, dtype=np.float32)
        self.action_space = spaces.Discrete(len(self._templates))

    def step(self, action: int):
        continuous_action = self._templates[action]
        return self.env.step(continuous_action)

    def template(self, action: int) -> np.ndarray:
        return self._templates[action]
