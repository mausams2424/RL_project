"""
agents/base.py
--------------
Abstract base class for all RL agents.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

import numpy as np


class BaseAgent(ABC):
    """Common interface every agent must implement."""

    def __init__(self, name: str = "BaseAgent"):
        self.name = name

    @abstractmethod
    def act(self, state: np.ndarray, **kwargs) -> int | np.ndarray:
        """Select an action given the current state."""

    @abstractmethod
    def learn(
        self,
        state: np.ndarray,
        action,
        reward: float,
        next_state: np.ndarray,
        done: bool,
        **kwargs,
    ) -> float | None:
        """Update internal parameters from a single transition. Returns loss or None."""

    def save(self, path: str | Path) -> None:
        """Persist agent state to disk (optional)."""

    def load(self, path: str | Path) -> None:
        """Restore agent state from disk (optional)."""

    def reset_episode(self) -> None:
        """Called at the start of each episode (optional)."""
