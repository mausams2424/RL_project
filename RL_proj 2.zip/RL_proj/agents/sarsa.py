"""
agents/sarsa.py
---------------
On-policy tabular SARSA agent with ε-greedy exploration.

The update uses the *actual* next action (on-policy), unlike Q-Learning.
"""

from __future__ import annotations

from collections import defaultdict

import numpy as np
from .base import BaseAgent


class SARSAAgent(BaseAgent):
    """
    On-policy SARSA with tabular Q-function.

    The agent stores the next_action chosen at time t so the trainer
    can pass it back via learn(..., next_action=…).

    Parameters
    ----------  (same as QLearningAgent)
    """

    def __init__(
        self,
        n_actions: int,
        lr: float = 0.05,
        gamma: float = 0.99,
        epsilon: float = 1.0,
        epsilon_decay: float = 0.9995,
        epsilon_min: float = 0.05,
        bins: int = 5,
    ):
        super().__init__(name="SARSA")
        self.n_actions = n_actions
        self.lr = lr
        self.gamma = gamma
        self.epsilon = epsilon
        self.epsilon_decay = epsilon_decay
        self.epsilon_min = epsilon_min
        self.bins = bins

        self.q_table: dict[int, np.ndarray] = defaultdict(
            lambda: np.zeros(n_actions, dtype=np.float64)
        )
        self._next_action: int | None = None

    # ------------------------------------------------------------------
    def _hash(self, state: np.ndarray) -> int:
        discretised = np.round(state * self.bins).astype(np.int16)
        return hash(discretised.tobytes())

    def _epsilon_greedy(self, state_key: int) -> int:
        if np.random.rand() < self.epsilon:
            return int(np.random.randint(self.n_actions))
        return int(np.argmax(self.q_table[state_key]))

    # ------------------------------------------------------------------
    def act(self, state: np.ndarray, **kwargs) -> int:
        key = self._hash(state)
        action = self._epsilon_greedy(key)
        return action

    def learn(
        self,
        state: np.ndarray,
        action: int,
        reward: float,
        next_state: np.ndarray,
        done: bool,
        next_action: int | None = None,
        **kwargs,
    ) -> float:
        s = self._hash(state)
        s2 = self._hash(next_state)

        # SARSA uses the NEXT chosen action, not the greedy best
        if next_action is None:
            next_action = self._epsilon_greedy(s2)

        next_q = 0.0 if done else float(self.q_table[s2][next_action])
        target = reward + self.gamma * next_q
        td_error = target - self.q_table[s][action]
        self.q_table[s][action] += self.lr * td_error

        self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)
        return float(abs(td_error))

    def reset_episode(self) -> None:
        self._next_action = None
