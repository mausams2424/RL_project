"""
agents/actor_critic.py
-----------------------
Advantage Actor-Critic (A2C) agent for *continuous* portfolio allocation.

Architecture:
  • Shared encoder  →  two separate heads: Actor & Critic
  • Actor  : outputs mean and log-std of a Gaussian; actions sampled and
             projected to valid portfolio weights via softmax
  • Critic : scalar V(s) estimate
  • Update : single-step TD(0) advantage — lightweight, no n-step rollouts
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.distributions import Normal

from .base import BaseAgent


# ─────────────────────────────────────────────────────────────────────────────
# Network
# ─────────────────────────────────────────────────────────────────────────────

class ActorCriticNet(nn.Module):
    """Shared-trunk Actor-Critic network."""

    def __init__(self, state_dim: int, action_dim: int, hidden: int = 256):
        super().__init__()
        self.trunk = nn.Sequential(
            nn.Linear(state_dim, hidden),
            nn.LayerNorm(hidden),
            nn.Tanh(),
            nn.Linear(hidden, hidden),
            nn.LayerNorm(hidden),
            nn.Tanh(),
        )
        self.actor_mean = nn.Linear(hidden, action_dim)
        self.actor_log_std = nn.Parameter(torch.zeros(action_dim))
        self.critic = nn.Linear(hidden, 1)

        # Orthogonal init
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.orthogonal_(m.weight, gain=np.sqrt(2))
                nn.init.zeros_(m.bias)
        nn.init.orthogonal_(self.actor_mean.weight, gain=0.01)

    def forward(self, x: torch.Tensor):
        h = self.trunk(x)
        mean = self.actor_mean(h)
        log_std = self.actor_log_std.clamp(-4, 2)
        value = self.critic(h).squeeze(-1)
        return mean, log_std.exp(), value


# ─────────────────────────────────────────────────────────────────────────────
# Agent
# ─────────────────────────────────────────────────────────────────────────────

class ActorCriticAgent(BaseAgent):
    """
    Continuous-action Advantage Actor-Critic.

    Parameters
    ----------
    state_dim      : obs dimension
    action_dim     : portfolio weight vector length (n_assets + 1)
    lr_actor       : Actor learning rate
    lr_critic      : Critic learning rate
    gamma          : discount factor γ
    entropy_coef   : entropy regularisation coefficient
    hidden         : hidden layer width
    grad_clip      : max gradient norm
    """

    def __init__(
        self,
        state_dim: int,
        action_dim: int,
        lr_actor: float = 3e-4,
        lr_critic: float = 1e-3,
        gamma: float = 0.99,
        entropy_coef: float = 0.01,
        hidden: int = 256,
        grad_clip: float = 0.5,
    ):
        super().__init__(name="ActorCritic")
        self.gamma = gamma
        self.entropy_coef = entropy_coef
        self.grad_clip = grad_clip

        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.net = ActorCriticNet(state_dim, action_dim, hidden).to(self.device)

        # Separate optimisers for actor and critic parameters
        actor_params = (
            list(self.net.trunk.parameters())
            + list(self.net.actor_mean.parameters())
            + [self.net.actor_log_std]
        )
        critic_params = (
            list(self.net.trunk.parameters())
            + list(self.net.critic.parameters())
        )
        self.opt_actor = optim.Adam(actor_params, lr=lr_actor)
        self.opt_critic = optim.Adam(critic_params, lr=lr_critic)

        # Store tensors from act() to use in learn()
        self._last_log_prob: torch.Tensor | None = None
        self._last_value: torch.Tensor | None = None
        self._last_entropy: torch.Tensor | None = None

    # ------------------------------------------------------------------
    def act(self, state: np.ndarray, **kwargs) -> np.ndarray:
        s = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        # We need the graph for the training step (learn), so NO torch.no_grad() here
        mean, std, value = self.net(s)
        dist = Normal(mean, std)
        raw_action = dist.rsample()                        # reparameterised
        self._last_log_prob = dist.log_prob(raw_action).sum(dim=-1)
        self._last_value = value
        self._last_entropy = dist.entropy().sum(dim=-1)
        return raw_action.squeeze(0).detach().cpu().numpy()

    def get_action_dist(self, state: np.ndarray) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Expose distribution parameters for confidence calculation (inference only)."""
        s = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        with torch.no_grad():
            return self.net(s)

    def learn(
        self,
        state: np.ndarray,
        action: np.ndarray,
        reward: float,
        next_state: np.ndarray,
        done: bool,
        **kwargs,
    ) -> float:
        if self._last_log_prob is None or self._last_value is None:
            return 0.0

        # Compute next value (detached) for TD target
        s2 = torch.FloatTensor(next_state).unsqueeze(0).to(self.device)
        with torch.no_grad():
            _, _, next_value = self.net(s2)
        
        target = reward + self.gamma * next_value.item() * (1 - float(done))
        
        # Advantage is computed using item() to treat it as a constant for the policy gradient
        # but we use the attached self._last_value for the critic loss
        advantage = target - self._last_value.item()

        # ── Critic loss (MSE between prediction and TD target) ────────
        # self._last_value is still connected to the graph from act()
        critic_loss = 0.5 * (self._last_value - target).pow(2)

        # ── Actor loss (policy gradient + entropy bonus) ───────────────
        # self._last_log_prob and self._last_entropy are connected to the graph
        actor_loss = -(
            self._last_log_prob * advantage
            + self.entropy_coef * self._last_entropy
        )

        total_loss = actor_loss + critic_loss

        self.opt_actor.zero_grad()
        self.opt_critic.zero_grad()
        total_loss.backward()
        
        if self.grad_clip:
            nn.utils.clip_grad_norm_(self.net.parameters(), self.grad_clip)
            
        self.opt_actor.step()
        self.opt_critic.step()

        # Detach and clear to avoid memory leaks and graph issues in next step
        loss_val = float(total_loss.item())
        self.reset_episode() 
        return loss_val

    # ------------------------------------------------------------------
    def save(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        torch.save(
            {
                "net": self.net.state_dict(),
                "opt_actor": self.opt_actor.state_dict(),
                "opt_critic": self.opt_critic.state_dict(),
            },
            path,
        )

    def load(self, path: str | Path) -> None:
        ckpt = torch.load(path, map_location=self.device)
        self.net.load_state_dict(ckpt["net"])
        self.opt_actor.load_state_dict(ckpt["opt_actor"])
        self.opt_critic.load_state_dict(ckpt["opt_critic"])

    def reset_episode(self) -> None:
        self._last_log_prob = None
        self._last_value = None
        self._last_entropy = None
