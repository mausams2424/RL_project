"""
agents/q_learning.py
---------------------
Tabular Q-Learning agent for the discretised portfolio environment.

State hashing uses a hash of the observation vector (binned at 1 decimal place
to keep the table manageable while still being state-sensitive).
"""

from __future__ import annotations

from collections import defaultdict

import numpy as np
from .base import BaseAgent


class QLearningAgent(BaseAgent):
    """
    Off-policy tabular Q-Learning (Watkins, 1989).

    Supports ε-greedy exploration with linear or exponential decay.

    Parameters
    ----------
    n_actions     : number of discrete actions
    lr            : learning rate α
    gamma         : discount factor γ
    epsilon       : initial exploration rate
    epsilon_decay : multiplicative decay (per step)
    epsilon_min   : minimum epsilon
    bins          : number of bins for state discretisation per feature dimension
    """

    def __init__(
        self,
        n_actions: int,
        lr: float = 0.05,
        gamma: float = 0.99,
        epsilon: float = 1.0,
        epsilon_decay: float = 0.9995,
        epsilon_min: float = 0.05,
        bins: int = 5,
    ):
        super().__init__(name="QLearning")
        self.n_actions = n_actions
        self.lr = lr
        self.gamma = gamma
        self.epsilon = epsilon
        self.epsilon_decay = epsilon_decay
        self.epsilon_min = epsilon_min
        self.bins = bins

        # Lazy defaultdict → new state rows are zeros
        self.q_table: dict[int, np.ndarray] = defaultdict(
            lambda: np.zeros(n_actions, dtype=np.float64)
        )

    # ------------------------------------------------------------------
    def _hash(self, state: np.ndarray) -> int:
        """Discretise state and return a hashable key."""
        discretised = np.round(state * self.bins).astype(np.int16)
        return hash(discretised.tobytes())

    # ------------------------------------------------------------------
    def act(self, state: np.ndarray, **kwargs) -> int:
        if np.random.rand() < self.epsilon:
            return int(np.random.randint(self.n_actions))
        key = self._hash(state)
        return int(np.argmax(self.q_table[key]))

    def learn(
        self,
        state: np.ndarray,
        action: int,
        reward: float,
        next_state: np.ndarray,
        done: bool,
        **kwargs,
    ) -> float:
        s = self._hash(state)
        s2 = self._hash(next_state)

        best_next = 0.0 if done else float(np.max(self.q_table[s2]))
        target = reward + self.gamma * best_next
        td_error = target - self.q_table[s][action]
        self.q_table[s][action] += self.lr * td_error

        # Decay epsilon
        self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)
        return float(abs(td_error))

    def reset_episode(self) -> None:
        pass
