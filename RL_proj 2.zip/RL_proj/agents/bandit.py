"""
agents/bandit.py
----------------
Multi-Armed Bandit agents for the discretised portfolio environment.

Two strategies:
  • EpsilonGreedyBandit  – classic ε-greedy with sample-mean value estimates
  • UCBBandit            – Upper Confidence Bound (UCB1)
"""

from __future__ import annotations

import numpy as np
from .base import BaseAgent


class EpsilonGreedyBandit(BaseAgent):
    """
    Epsilon-Greedy Multi-Armed Bandit.

    Ignores state (pure bandit); maintains running Q-value for each action.
    Epsilon is optionally decayed over time.

    Parameters
    ----------
    n_actions     : number of discrete actions
    epsilon       : initial exploration probability
    epsilon_decay : multiplicative decay applied after each learn() call
    epsilon_min   : lower bound on epsilon
    """

    def __init__(
        self,
        n_actions: int,
        epsilon: float = 0.2,
        epsilon_decay: float = 0.9995,
        epsilon_min: float = 0.05,
    ):
        super().__init__(name="EpsilonGreedyBandit")
        self.n_actions = n_actions
        self.epsilon = epsilon
        self.epsilon_decay = epsilon_decay
        self.epsilon_min = epsilon_min

        self.q_values = np.zeros(n_actions, dtype=np.float64)
        self.counts = np.zeros(n_actions, dtype=np.int64)

    def act(self, state: np.ndarray | None = None, **kwargs) -> int:
        if np.random.rand() < self.epsilon:
            return int(np.random.randint(self.n_actions))
        return int(np.argmax(self.q_values))

    def learn(
        self,
        state: np.ndarray,
        action: int,
        reward: float,
        next_state: np.ndarray,
        done: bool,
        **kwargs,
    ) -> None:
        self.counts[action] += 1
        # Incremental mean update
        self.q_values[action] += (reward - self.q_values[action]) / self.counts[action]
        # Decay exploration
        self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)

    def reset_episode(self) -> None:
        pass  # bandit keeps its estimates across episodes


class UCBBandit(BaseAgent):
    """
    Upper Confidence Bound (UCB1) Multi-Armed Bandit.

    UCB score = Q(a) + c * sqrt(ln(t) / N(a))
    where t is total steps and N(a) is action selection count.
    """

    def __init__(self, n_actions: int, c: float = 1.5):
        super().__init__(name="UCBBandit")
        self.n_actions = n_actions
        self.c = c

        self.q_values = np.zeros(n_actions, dtype=np.float64)
        self.counts = np.zeros(n_actions, dtype=np.int64)
        self.total_steps = 0

    def act(self, state: np.ndarray | None = None, **kwargs) -> int:
        self.total_steps += 1
        # Force-explore arms not yet tried
        untried = np.where(self.counts == 0)[0]
        if len(untried) > 0:
            return int(untried[0])
        ucb_scores = self.q_values + self.c * np.sqrt(
            np.log(self.total_steps) / (self.counts + 1e-9)
        )
        return int(np.argmax(ucb_scores))

    def learn(
        self,
        state: np.ndarray,
        action: int,
        reward: float,
        next_state: np.ndarray,
        done: bool,
        **kwargs,
    ) -> None:
        self.counts[action] += 1
        self.q_values[action] += (reward - self.q_values[action]) / self.counts[action]

    def reset_episode(self) -> None:
        pass
