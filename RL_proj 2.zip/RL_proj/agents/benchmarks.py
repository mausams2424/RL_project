"""
agents/benchmarks.py
---------------------
Passive baseline agents for benchmarking RL performance.

BuyAndHoldAgent : allocates uniformly across all assets on step 1, then holds.
RandomAgent     : selects random portfolio weights (softmax) each step.

Both implement the BaseAgent interface for seamless Trainer compatibility.
"""

from __future__ import annotations

import numpy as np

from .base import BaseAgent


class BuyAndHoldAgent(BaseAgent):
    """
    Buy-and-Hold strategy: uniform allocation across all assets, ignoring cash.
    After the first action, all subsequent actions return the same initial weights.

    This is the standard passive benchmark in portfolio management research.
    """

    def __init__(self, n_actions: int):
        """
        Parameters
        ----------
        n_actions : total allocation slots (n_assets + 1 for cash)
        """
        super().__init__(name="Buy & Hold")
        self.n_actions = n_actions
        self._initial_weights: np.ndarray | None = None

    def act(self, state: np.ndarray, **kwargs) -> np.ndarray:
        if self._initial_weights is None:
            # Uniform across assets only (last slot = cash, set to 0)
            weights = np.zeros(self.n_actions, dtype=np.float32)
            asset_weight = 1.0 / max(self.n_actions - 1, 1)
            weights[:-1] = asset_weight  # equal weight on all assets
            weights[-1] = 0.0            # no cash
            self._initial_weights = weights
        return self._initial_weights.copy()

    def learn(self, state, action, reward, next_state, done, **kwargs) -> None:
        return None  # Passive — no learning

    def save(self, path) -> None:
        pass

    def load(self, path) -> None:
        pass

    def reset_episode(self) -> None:
        # Keep weights across episodes — it's buy-and-hold
        pass


class RandomAgent(BaseAgent):
    """
    Random baseline: samples a random softmax weight vector each step.
    Sets the floor expectation for any RL agent to beat.
    """

    def __init__(self, n_actions: int, seed: int | None = None):
        """
        Parameters
        ----------
        n_actions : total allocation slots (n_assets + 1 for cash)
        seed      : optional RNG seed for reproducibility
        """
        super().__init__(name="Random")
        self.n_actions = n_actions
        self.rng = np.random.default_rng(seed)

    @staticmethod
    def _softmax(x: np.ndarray) -> np.ndarray:
        e = np.exp(x - np.max(x))
        return e / (e.sum() + 1e-9)

    def act(self, state: np.ndarray, **kwargs) -> np.ndarray:
        raw = self.rng.normal(0, 1, self.n_actions).astype(np.float32)
        return self._softmax(raw)

    def learn(self, state, action, reward, next_state, done, **kwargs) -> None:
        return None  # No learning

    def save(self, path) -> None:
        pass

    def load(self, path) -> None:
        pass

    def reset_episode(self) -> None:
        pass
