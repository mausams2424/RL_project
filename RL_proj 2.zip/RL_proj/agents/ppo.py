"""
agents/ppo.py
--------------
Proximal Policy Optimisation (PPO) with clipped surrogate objective.

Architecture:
  • Shared trunk → Actor head (Gaussian mean + log-std) + Critic head (V(s))
  • Rollout buffer collects T steps per update (default 2048)
  • Mini-batch updates over K epochs (default 10)
  • Compatible with continuous portfolio weight action space

Key hyperparameters:
  clip_eps     : clipping range for surrogate objective (default 0.2)
  vf_coef      : value loss coefficient
  entropy_coef : entropy bonus coefficient
  n_epochs     : gradient steps per rollout
  rollout_len  : steps before each policy update
"""

from __future__ import annotations

from collections import deque
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.distributions import Normal

from .base import BaseAgent


# ─────────────────────────────────────────────────────────────────────────────
# Network
# ─────────────────────────────────────────────────────────────────────────────

class PPONetwork(nn.Module):
    """Shared-trunk Actor-Critic network for PPO."""

    def __init__(self, state_dim: int, action_dim: int, hidden: int = 256):
        super().__init__()
        self.trunk = nn.Sequential(
            nn.Linear(state_dim, hidden),
            nn.LayerNorm(hidden),
            nn.Tanh(),
            nn.Linear(hidden, hidden),
            nn.LayerNorm(hidden),
            nn.Tanh(),
        )
        self.actor_mean = nn.Linear(hidden, action_dim)
        self.actor_log_std = nn.Parameter(torch.full((action_dim,), -0.5))
        self.critic = nn.Linear(hidden, 1)

        # Orthogonal initialisation for stable training
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.orthogonal_(m.weight, gain=np.sqrt(2))
                nn.init.zeros_(m.bias)
        nn.init.orthogonal_(self.actor_mean.weight, gain=0.01)

    def forward(self, x: torch.Tensor):
        h = self.trunk(x)
        mean = self.actor_mean(h)
        log_std = self.actor_log_std.clamp(-4, 2)
        value = self.critic(h).squeeze(-1)
        return mean, log_std.exp(), value


# ─────────────────────────────────────────────────────────────────────────────
# Rollout Buffer
# ─────────────────────────────────────────────────────────────────────────────

class RolloutBuffer:
    """Stores a fixed-length rollout for PPO mini-batch updates."""

    def __init__(self, rollout_len: int, state_dim: int, action_dim: int, gamma: float, gae_lambda: float):
        self.rollout_len = rollout_len
        self.gamma = gamma
        self.gae_lambda = gae_lambda

        self.states = np.zeros((rollout_len, state_dim), dtype=np.float32)
        self.actions = np.zeros((rollout_len, action_dim), dtype=np.float32)
        self.rewards = np.zeros(rollout_len, dtype=np.float32)
        self.dones = np.zeros(rollout_len, dtype=np.float32)
        self.values = np.zeros(rollout_len, dtype=np.float32)
        self.log_probs = np.zeros(rollout_len, dtype=np.float32)
        self.advantages = np.zeros(rollout_len, dtype=np.float32)
        self.returns = np.zeros(rollout_len, dtype=np.float32)
        self._ptr = 0

    def add(self, state, action, reward, done, value, log_prob):
        if self._ptr >= self.rollout_len:
            return
        self.states[self._ptr] = state
        self.actions[self._ptr] = action
        self.rewards[self._ptr] = reward
        self.dones[self._ptr] = float(done)
        self.values[self._ptr] = value
        self.log_probs[self._ptr] = log_prob
        self._ptr += 1

    def compute_gae(self, last_value: float) -> None:
        """Generalised Advantage Estimation (GAE-λ)."""
        gae = 0.0
        for t in reversed(range(self._ptr)):
            next_val = last_value if t == self._ptr - 1 else self.values[t + 1]
            delta = self.rewards[t] + self.gamma * next_val * (1 - self.dones[t]) - self.values[t]
            gae = delta + self.gamma * self.gae_lambda * (1 - self.dones[t]) * gae
            self.advantages[t] = gae
            self.returns[t] = gae + self.values[t]

    def get(self, device: torch.device):
        n = self._ptr
        adv = self.advantages[:n]
        adv = (adv - adv.mean()) / (adv.std() + 1e-8)
        return (
            torch.FloatTensor(self.states[:n]).to(device),
            torch.FloatTensor(self.actions[:n]).to(device),
            torch.FloatTensor(self.log_probs[:n]).to(device),
            torch.FloatTensor(adv).to(device),
            torch.FloatTensor(self.returns[:n]).to(device),
        )

    def reset(self):
        self._ptr = 0

    @property
    def is_full(self) -> bool:
        return self._ptr >= self.rollout_len

    def __len__(self):
        return self._ptr


# ─────────────────────────────────────────────────────────────────────────────
# PPO Agent
# ─────────────────────────────────────────────────────────────────────────────

class PPOAgent(BaseAgent):
    """
    Proximal Policy Optimisation agent for continuous portfolio allocation.

    Parameters
    ----------
    state_dim       : observation vector dimension
    action_dim      : portfolio weight vector length (n_assets + 1)
    lr              : learning rate (shared for actor+critic)
    gamma           : discount factor γ
    gae_lambda      : GAE λ (0 = TD(0), 1 = MC)
    clip_eps        : PPO clipping parameter ε
    vf_coef         : value function loss weight
    entropy_coef    : entropy bonus weight
    n_epochs        : gradient update passes per rollout
    rollout_len     : steps to collect before each update
    batch_size      : mini-batch size within each epoch
    hidden          : hidden layer width
    grad_clip       : max gradient norm
    """

    def __init__(
        self,
        state_dim: int,
        action_dim: int,
        lr: float = 3e-4,
        gamma: float = 0.99,
        gae_lambda: float = 0.95,
        clip_eps: float = 0.2,
        vf_coef: float = 0.5,
        entropy_coef: float = 0.01,
        n_epochs: int = 10,
        rollout_len: int = 512,
        batch_size: int = 64,
        hidden: int = 256,
        grad_clip: float = 0.5,
    ):
        super().__init__(name="PPO")
        self.gamma = gamma
        self.clip_eps = clip_eps
        self.vf_coef = vf_coef
        self.entropy_coef = entropy_coef
        self.n_epochs = n_epochs
        self.batch_size = batch_size
        self.grad_clip = grad_clip

        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.net = PPONetwork(state_dim, action_dim, hidden).to(self.device)
        self.optimizer = optim.Adam(self.net.parameters(), lr=lr)

        self.buffer = RolloutBuffer(rollout_len, state_dim, action_dim, gamma, gae_lambda)

        # Track last step values for learn()
        self._last_value: float = 0.0
        self._last_log_prob: float = 0.0
        self._last_action: np.ndarray | None = None
        self._last_losses: list[float] = []
        self._update_count: int = 0

    # ------------------------------------------------------------------
    def act(self, state: np.ndarray, **kwargs) -> np.ndarray:
        s = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        with torch.no_grad():
            mean, std, value = self.net(s)
        dist = Normal(mean, std)
        action = dist.sample()
        log_prob = dist.log_prob(action).sum(dim=-1)

        self._last_value = value.item()
        self._last_log_prob = log_prob.item()
        self._last_action = action.squeeze(0).cpu().numpy()
        return self._last_action

    def get_action_dist(self, state: np.ndarray):
        """Expose distribution parameters (for confidence / explainability)."""
        s = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        with torch.no_grad():
            mean, std, value = self.net(s)
        return mean, std, value

    def learn(
        self,
        state: np.ndarray,
        action,
        reward: float,
        next_state: np.ndarray,
        done: bool,
        **kwargs,
    ) -> float | None:
        if self._last_action is None:
            return None

        self.buffer.add(
            state,
            self._last_action,
            reward,
            done,
            self._last_value,
            self._last_log_prob,
        )

        if not self.buffer.is_full and not done:
            return None

        # Compute last value for GAE bootstrapping
        if done:
            last_val = 0.0
        else:
            s2 = torch.FloatTensor(next_state).unsqueeze(0).to(self.device)
            with torch.no_grad():
                _, _, last_val_t = self.net(s2)
            last_val = last_val_t.item()

        self.buffer.compute_gae(last_val)
        loss_val = self._update()
        self.buffer.reset()
        self._update_count += 1
        return loss_val

    def _update(self) -> float:
        states, actions, old_log_probs, advantages, returns = self.buffer.get(self.device)
        n = len(states)
        total_loss = 0.0
        num_updates = 0

        for _ in range(self.n_epochs):
            indices = torch.randperm(n)
            for start in range(0, n, self.batch_size):
                idx = indices[start: start + self.batch_size]

                s_b = states[idx]
                a_b = actions[idx]
                old_lp_b = old_log_probs[idx]
                adv_b = advantages[idx]
                ret_b = returns[idx]

                mean, std, value = self.net(s_b)
                dist = Normal(mean, std)
                new_log_prob = dist.log_prob(a_b).sum(dim=-1)
                entropy = dist.entropy().sum(dim=-1).mean()

                ratio = (new_log_prob - old_lp_b).exp()
                pg_loss1 = -adv_b * ratio
                pg_loss2 = -adv_b * ratio.clamp(1 - self.clip_eps, 1 + self.clip_eps)
                policy_loss = torch.max(pg_loss1, pg_loss2).mean()

                value_loss = ((value - ret_b) ** 2).mean()

                loss = policy_loss + self.vf_coef * value_loss - self.entropy_coef * entropy

                self.optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(self.net.parameters(), self.grad_clip)
                self.optimizer.step()

                total_loss += loss.item()
                num_updates += 1

        return total_loss / max(num_updates, 1)

    # ------------------------------------------------------------------
    def save(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        torch.save(
            {
                "net": self.net.state_dict(),
                "optimizer": self.optimizer.state_dict(),
                "update_count": self._update_count,
            },
            path,
        )

    def load(self, path: str | Path) -> None:
        ckpt = torch.load(path, map_location=self.device)
        self.net.load_state_dict(ckpt["net"])
        self.optimizer.load_state_dict(ckpt["optimizer"])
        self._update_count = ckpt.get("update_count", 0)

    def reset_episode(self) -> None:
        self._last_value = 0.0
        self._last_log_prob = 0.0
        self._last_action = None
        self.buffer.reset()
