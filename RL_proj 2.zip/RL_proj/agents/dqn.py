"""
agents/dqn.py
--------------
Deep Q-Network (DQN) agent with:
  • Prioritised-agnostic Replay Buffer (uniform sampling, configurable)
  • Separate Policy and Target networks
  • Huber loss for stability
  • Gradient clipping
  • Double-DQN update rule (optional)
"""

from __future__ import annotations

import random
from collections import deque
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim

from .base import BaseAgent


# ─────────────────────────────────────────────────────────────────────────────
# Neural Network
# ─────────────────────────────────────────────────────────────────────────────

class QNetwork(nn.Module):
    """3-layer MLP Q-function with LayerNorm for training stability."""

    def __init__(self, state_dim: int, action_dim: int, hidden: int = 256):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden),
            nn.ReLU(),
            nn.Linear(hidden, hidden),
            nn.ReLU(),
            nn.Linear(hidden, action_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


# ─────────────────────────────────────────────────────────────────────────────
# Replay Buffer
# ─────────────────────────────────────────────────────────────────────────────

class ReplayBuffer:
    """Fixed-size uniform replay buffer."""

    def __init__(self, capacity: int = 50_000):
        self.buffer: deque = deque(maxlen=capacity)

    def push(
        self,
        state: np.ndarray,
        action: int,
        reward: float,
        next_state: np.ndarray,
        done: bool,
    ) -> None:
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size: int):
        batch = random.sample(self.buffer, batch_size)
        states, actions, rewards, next_states, dones = zip(*batch)
        return (
            np.array(states, dtype=np.float32),
            np.array(actions, dtype=np.int64),
            np.array(rewards, dtype=np.float32),
            np.array(next_states, dtype=np.float32),
            np.array(dones, dtype=np.float32),
        )

    def __len__(self) -> int:
        return len(self.buffer)


# ─────────────────────────────────────────────────────────────────────────────
# DQN Agent
# ─────────────────────────────────────────────────────────────────────────────

class DQNAgent(BaseAgent):
    """
    Deep Q-Network with optional Double-DQN.

    Parameters
    ----------
    state_dim        : dimension of the observation vector
    n_actions        : number of discrete actions
    lr               : Adam learning rate
    gamma            : discount factor γ
    epsilon          : initial exploration ε
    epsilon_decay    : multiplicative decay per learn() call
    epsilon_min      : minimum ε
    batch_size       : mini-batch size
    buffer_capacity  : replay buffer max size
    target_update    : hard-copy target network every N steps
    hidden           : hidden layer width
    double_dqn       : use Double-DQN if True
    grad_clip        : gradient clipping norm (None to disable)
    """

    def __init__(
        self,
        state_dim: int,
        n_actions: int,
        lr: float = 3e-4,
        gamma: float = 0.99,
        epsilon: float = 1.0,
        epsilon_decay: float = 0.9995,
        epsilon_min: float = 0.05,
        batch_size: int = 128,
        buffer_capacity: int = 50_000,
        target_update: int = 20,
        hidden: int = 256,
        double_dqn: bool = True,
        grad_clip: float | None = 1.0,
    ):
        super().__init__(name="DQN")
        self.n_actions = n_actions
        self.gamma = gamma
        self.epsilon = epsilon
        self.epsilon_decay = epsilon_decay
        self.epsilon_min = epsilon_min
        self.batch_size = batch_size
        self.target_update = target_update
        self.double_dqn = double_dqn
        self.grad_clip = grad_clip
        self._step = 0

        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        self.policy_net = QNetwork(state_dim, n_actions, hidden).to(self.device)
        self.target_net = QNetwork(state_dim, n_actions, hidden).to(self.device)
        for target_param, param in zip(self.target_net.parameters(), self.policy_net.parameters()):
            target_param.data.copy_(param.data)
        self.target_net.eval()

        self.optimizer = optim.Adam(self.policy_net.parameters(), lr=lr)
        self.loss_fn = nn.HuberLoss()
        self.memory = ReplayBuffer(buffer_capacity)

    # ------------------------------------------------------------------
    def act(self, state: np.ndarray, **kwargs) -> int:
        if np.random.rand() < self.epsilon:
            return int(np.random.randint(self.n_actions))
        q = self.get_q_values(state)
        return int(q.argmax(dim=1).item())

    def get_q_values(self, state: np.ndarray) -> torch.Tensor:
        """Expose raw Q-values for confidence calculation."""
        s = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        with torch.no_grad():
            return self.policy_net(s)

    def learn(
        self,
        state: np.ndarray,
        action: int,
        reward: float,
        next_state: np.ndarray,
        done: bool,
        **kwargs,
    ) -> float | None:
        self.memory.push(state, action, reward, next_state, done)
        if len(self.memory) < self.batch_size:
            return None

        states, actions, rewards, next_states, dones = self.memory.sample(
            self.batch_size
        )

        S  = torch.FloatTensor(states).to(self.device)
        A  = torch.LongTensor(actions).unsqueeze(1).to(self.device)
        R  = torch.FloatTensor(rewards).unsqueeze(1).to(self.device)
        S2 = torch.FloatTensor(next_states).to(self.device)
        D  = torch.FloatTensor(dones).unsqueeze(1).to(self.device)

        q_vals = self.policy_net(S).gather(1, A)

        with torch.no_grad():
            if self.double_dqn:
                best_actions = self.policy_net(S2).argmax(dim=1, keepdim=True)
                next_q = self.target_net(S2).gather(1, best_actions)
            else:
                next_q = self.target_net(S2).max(dim=1, keepdim=True)[0]
            targets = R + self.gamma * next_q * (1.0 - D)

        loss: torch.Tensor = self.loss_fn(q_vals, targets)

        self.optimizer.zero_grad()
        loss.backward()
        if self.grad_clip is not None:
            nn.utils.clip_grad_norm_(self.policy_net.parameters(), self.grad_clip)
        self.optimizer.step()

        self._step += 1
        self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)

        if self._step % self.target_update == 0:
            for target_param, param in zip(self.target_net.parameters(), self.policy_net.parameters()):
                target_param.data.copy_(param.data)

        return loss.item()

    # ------------------------------------------------------------------
    def save(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        torch.save(
            {
                "policy_net": self.policy_net.state_dict(),
                "target_net": self.target_net.state_dict(),
                "optimizer": self.optimizer.state_dict(),
                "epsilon": self.epsilon,
                "step": self._step,
            },
            path,
        )

    def load(self, path: str | Path) -> None:
        ckpt = torch.load(path, map_location=self.device)
        self.policy_net.load_state_dict(ckpt["policy_net"])
        self.target_net.load_state_dict(ckpt["target_net"])
        self.optimizer.load_state_dict(ckpt["optimizer"])
        self.epsilon = ckpt["epsilon"]
        self._step = ckpt["step"]

    def reset_episode(self) -> None:
        pass
