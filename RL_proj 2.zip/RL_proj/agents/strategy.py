"""
agents/strategy.py
-------------------
Strategy modes for portfolio agents.

StrategyMode  : Enum defining Conservative / Balanced / Aggressive profiles.
StrategyWrapper : Wraps any BaseAgent and post-processes its continuous action
                  to enforce the selected risk profile.

Conservative  → clamps asset weights down, raises minimum cash floor to 35%.
Balanced      → passes action through unchanged (default RL behaviour).
Aggressive    → scales up asset weights (reduces cash), renormalised via softmax.

Usage
-----
    agent = DQNAgent(...)
    wrapped = StrategyWrapper(agent, StrategyMode.CONSERVATIVE)
    action = wrapped.act(state)       # strategy-adjusted weights
    loss = wrapped.learn(...)         # delegates straight to inner agent
"""

from __future__ import annotations

from enum import Enum

import numpy as np

from .base import BaseAgent


class StrategyMode(str, Enum):
    CONSERVATIVE = "Conservative"
    BALANCED = "Balanced"
    AGGRESSIVE = "Aggressive"


# ─────────────────────────────────────────────────────────────────────────────
# Strategy Wrapper
# ─────────────────────────────────────────────────────────────────────────────

class StrategyWrapper(BaseAgent):
    """
    Wraps a trained agent and adjusts its continuous portfolio weight output
    according to the specified risk strategy mode.

    All learning and save/load calls delegate directly to the inner agent.

    Parameters
    ----------
    agent          : any BaseAgent instance (DQN, ActorCritic, PPO, …)
    mode           : StrategyMode enum value
    min_cash_conservative : minimum cash reserve in Conservative mode (default 0.35)
    asset_scale_aggressive : multiplier applied to asset weights in Aggressive mode
    """

    def __init__(
        self,
        agent: BaseAgent,
        mode: StrategyMode = StrategyMode.BALANCED,
        min_cash_conservative: float = 0.35,
        asset_scale_aggressive: float = 1.40,
    ):
        super().__init__(name=f"{agent.name}[{mode.value}]")
        self.agent = agent
        self.mode = mode
        self.min_cash_conservative = min_cash_conservative
        self.asset_scale_aggressive = asset_scale_aggressive

    @staticmethod
    def _softmax(x: np.ndarray) -> np.ndarray:
        e = np.exp(x - np.max(x))
        return e / (e.sum() + 1e-9)

    # ------------------------------------------------------------------
    def _apply_strategy(self, raw_weights: np.ndarray) -> np.ndarray:
        """
        Adjust a raw continuous action vector according to the strategy mode.

        Expects raw_weights already in valid portfolio weight space (summing to 1).
        For discrete agents that return an integer, returns it unchanged.
        """
        if isinstance(raw_weights, (int, np.integer)):
            return raw_weights  # discrete action — no modification possible

        weights = raw_weights.copy().astype(np.float64)

        if self.mode == StrategyMode.CONSERVATIVE:
            # Scale down all asset weights by 0.6; pump up cash
            weights[:-1] *= 0.60
            weights[-1] = 1.0 - weights[:-1].sum()
            # Enforce minimum cash floor
            if weights[-1] < self.min_cash_conservative:
                deficit = self.min_cash_conservative - weights[-1]
                # Trim assets proportionally
                total_assets = weights[:-1].sum()
                if total_assets > 0:
                    weights[:-1] *= (total_assets - deficit) / total_assets
                weights[-1] = self.min_cash_conservative
            # Renorm
            weights = np.clip(weights, 0, 1)
            weights /= (weights.sum() + 1e-9)

        elif self.mode == StrategyMode.AGGRESSIVE:
            # Scale up asset weights; reduce cash
            weights[:-1] *= self.asset_scale_aggressive
            # Clip and re-normalise via softmax-style projection
            weights = np.clip(weights, 0, 1)
            weights /= (weights.sum() + 1e-9)

        # BALANCED: no modification
        return weights.astype(np.float32)

    # ------------------------------------------------------------------
    def act(self, state: np.ndarray, **kwargs):
        raw = self.agent.act(state, **kwargs)
        return self._apply_strategy(raw)

    def learn(self, state, action, reward, next_state, done, **kwargs):
        return self.agent.learn(state, action, reward, next_state, done, **kwargs)

    def save(self, path) -> None:
        self.agent.save(path)

    def load(self, path) -> None:
        self.agent.load(path)

    def reset_episode(self) -> None:
        self.agent.reset_episode()

    # Expose inner agent for confidence / explainability access
    def get_action_dist(self, state: np.ndarray):
        if hasattr(self.agent, "get_action_dist"):
            return self.agent.get_action_dist(state)
        return None

    def get_q_values(self, state: np.ndarray):
        if hasattr(self.agent, "get_q_values"):
            return self.agent.get_q_values(state)
        return None
