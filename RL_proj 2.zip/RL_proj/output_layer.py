"""
output_layer.py
----------------
The Output Layer — Central communication bridge between the RL backend and the UI.

This module is the CORE DIFFERENTIATOR of the system. It:
  • Logs every RL step with full metadata (state, action, reward, weights, risk)
  • Maintains structured per-step history accessible as DataFrame or JSON
  • Generates human-readable explanations for every decision via ExplainabilityEngine
  • Provides real-time access to the latest decision and portfolio state
  • Produces episode-level summaries (total reward, final value, steps, drawdown)

Design principles:
  - Fully standalone — no dependency on agents or environments
  - Stateful per-episode, reset-able
  - Output is directly feed-able to a Streamlit dashboard or REST API

Example usage
-------------
    ol = OutputLayer(tickers=["AAPL", "MSFT", "GOOGL"])
    ol.log_step(
        episode=1, step=5,
        state_features={"rsi_mean": 58.2, "macd_signal": 0.003, "regime": "Bull"},
        raw_action=[0.3, 0.4, 0.2, 0.1],
        constrained_weights=[0.28, 0.38, 0.19, 0.15],
        old_weights=[0.25, 0.35, 0.20, 0.20],
        reward=0.0042,
        portfolio_value=103500.0,
        peak_value=104000.0,
    )
    print(ol.get_latest().explanation)
    print(ol.get_episode_summary())
    df = ol.get_history_df()
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Any

import numpy as np
import pandas as pd


# ─────────────────────────────────────────────────────────────────────────────
# StepRecord
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class StepRecord:
    """
    Immutable record of a single RL agent step, including explanation.

    All fields are JSON-serialisable for API/dashboard consumption.
    """
    episode: int
    step: int
    timestamp: str

    # Market state summary
    regime: str                         # "Bull" | "Bear" | "Sideways"
    rsi_mean: float                     # Average RSI across assets (0-100)
    macd_bullish_count: int             # Number of assets with bullish MACD
    volatility: float                   # Recent return std (annualised)

    # Action outputs
    raw_action: list[float]             # Pre-constraint weights from agent
    constrained_weights: list[float]    # Post-constraint weights applied
    old_weights: list[float]            # Weights from previous step
    action_labels: list[str]            # BUY / SELL / HOLD per asset+cash
    action_magnitudes: list[float]      # abs weight deltas per asset

    # Reward components
    reward: float
    raw_return: float
    risk_penalty: float

    # Portfolio state
    portfolio_value: float
    peak_value: float
    drawdown: float                     # Current drawdown from peak (0-1)

    # Explainability
    explanation: str                    # Human-readable NL explanation
    decision_factors: dict              # Structured dict of factors used

    # Metadata
    tickers: list[str]
    metadata: dict = field(default_factory=dict)


# ─────────────────────────────────────────────────────────────────────────────
# Explainability Engine
# ─────────────────────────────────────────────────────────────────────────────

class ExplainabilityEngine:
    """
    Converts raw RL decision data into human-readable, factor-based explanations.

    Uses deterministic rules over market indicators, portfolio state, and action
    magnitudes. No ML involved — fully transparent and auditable.
    """

    # RSI thresholds
    RSI_OVERSOLD = 35.0
    RSI_OVERBOUGHT = 65.0
    RSI_NEUTRAL_LOW = 45.0
    RSI_NEUTRAL_HIGH = 55.0

    # Action magnitude thresholds (weight delta)
    STRONG_ACTION = 0.12
    MODERATE_ACTION = 0.05
    MILD_ACTION = 0.02

    # Drawdown thresholds
    HIGH_DRAWDOWN = 0.10
    CRITICAL_DRAWDOWN = 0.20

    # Volatility thresholds (annualised std of log-returns)
    HIGH_VOL = 0.30
    LOW_VOL = 0.10

    def generate(
        self,
        tickers: list[str],
        old_weights: list[float],
        new_weights: list[float],
        action_labels: list[str],
        rsi_mean: float,
        macd_bullish_count: int,
        n_assets: int,
        regime: str,
        volatility: float,
        reward: float,
        raw_return: float,
        risk_penalty: float,
        portfolio_value: float,
        initial_value: float,
        peak_value: float,
        drawdown: float,
    ) -> tuple[str, dict]:
        """
        Build a human-readable explanation string and a structured factor dict.

        Returns
        -------
        explanation    : plain-English paragraphs suitable for display
        decision_factors : dict of labelled signals used
        """
        all_labels = tickers + ["Cash"]
        old_w = np.array(old_weights)
        new_w = np.array(new_weights)
        deltas = new_w - old_w

        # ── Identify primary action ───────────────────────────────────────
        buys = [(all_labels[i], deltas[i]) for i, lbl in enumerate(action_labels) if lbl == "BUY"]
        sells = [(all_labels[i], deltas[i]) for i, lbl in enumerate(action_labels) if lbl == "SELL"]
        holds = [all_labels[i] for i, lbl in enumerate(action_labels) if lbl == "HOLD"]

        # ── RSI signal ────────────────────────────────────────────────────
        if rsi_mean < self.RSI_OVERSOLD:
            rsi_signal = f"Oversold conditions (avg RSI {rsi_mean:.1f}) are signalling a potential buying opportunity."
            rsi_factor = "Oversold — buying opportunity"
        elif rsi_mean > self.RSI_OVERBOUGHT:
            rsi_signal = f"Overbought conditions (avg RSI {rsi_mean:.1f}) suggest reduced upside and possible correction risk."
            rsi_factor = "Overbought — caution advised"
        elif rsi_mean < self.RSI_NEUTRAL_LOW:
            rsi_signal = f"RSI is mildly weak ({rsi_mean:.1f}), suggesting cooling momentum."
            rsi_factor = "Mild weakness"
        elif rsi_mean > self.RSI_NEUTRAL_HIGH:
            rsi_signal = f"RSI is mildly strong ({rsi_mean:.1f}), indicating moderate upward momentum."
            rsi_factor = "Mild strength"
        else:
            rsi_signal = f"RSI is neutral ({rsi_mean:.1f}), giving no strong directional bias."
            rsi_factor = "Neutral"

        # ── MACD signal ───────────────────────────────────────────────────
        macd_ratio = macd_bullish_count / max(n_assets, 1)
        if macd_ratio >= 0.7:
            macd_signal = f"MACD is bullish on {macd_bullish_count}/{n_assets} assets, confirming positive price momentum."
            macd_factor = f"Bullish ({macd_bullish_count}/{n_assets} assets)"
        elif macd_ratio <= 0.3:
            macd_signal = f"MACD is bearish on {n_assets - macd_bullish_count}/{n_assets} assets, indicating waning momentum."
            macd_factor = f"Bearish ({n_assets - macd_bullish_count}/{n_assets} assets)"
        else:
            macd_signal = f"MACD shows mixed momentum ({macd_bullish_count}/{n_assets} assets bullish)."
            macd_factor = "Mixed"

        # ── Regime ───────────────────────────────────────────────────────
        if regime == "Bull":
            regime_signal = "The market is in a Bull regime — positive rolling trend supports risk-on positioning."
        elif regime == "Bear":
            regime_signal = "The market is in a Bear regime — negative rolling trend warrants defensive positioning."
        else:
            regime_signal = "The market is Sideways — range-bound conditions call for selective, balanced exposure."

        # ── Volatility ────────────────────────────────────────────────────
        if volatility > self.HIGH_VOL:
            vol_signal = f"High market volatility ({volatility:.1%} annualised) is increasing risk penalty and prompting weight reduction."
            vol_factor = f"High ({volatility:.1%})"
        elif volatility < self.LOW_VOL:
            vol_signal = f"Low volatility ({volatility:.1%} annualised) — stable conditions favour increased deployment."
            vol_factor = f"Low ({volatility:.1%})"
        else:
            vol_signal = f"Moderate volatility ({volatility:.1%} annualised) — within normal operating range."
            vol_factor = f"Moderate ({volatility:.1%})"

        # ── Drawdown ─────────────────────────────────────────────────────
        if drawdown > self.CRITICAL_DRAWDOWN:
            dd_signal = f"⚠️ Critical drawdown of {drawdown:.1%} from peak — risk constraints are enforcing defensive allocation."
            dd_factor = f"Critical ({drawdown:.1%})"
        elif drawdown > self.HIGH_DRAWDOWN:
            dd_signal = f"Elevated drawdown of {drawdown:.1%} — the agent is trimming exposure to protect capital."
            dd_factor = f"Elevated ({drawdown:.1%})"
        else:
            dd_signal = f"Drawdown is contained at {drawdown:.1%} — portfolio is near its peak value."
            dd_factor = f"Contained ({drawdown:.1%})"

        # ── Portfolio imbalance ───────────────────────────────────────────
        max_delta = float(np.max(np.abs(deltas[:-1]))) if len(deltas) > 1 else 0.0
        if max_delta > self.STRONG_ACTION:
            imbalance_signal = "A significant portfolio rebalancing is being executed."
            imbalance_factor = "Strong rebalance"
        elif max_delta > self.MODERATE_ACTION:
            imbalance_signal = "A moderate rebalancing is taking place to improve alignment with the target allocation."
            imbalance_factor = "Moderate rebalance"
        elif max_delta > self.MILD_ACTION:
            imbalance_signal = "Minor portfolio trimming/addition to keep allocations on track."
            imbalance_factor = "Minor trim"
        else:
            imbalance_signal = "Portfolio weights are close to target — minimal adjustment needed."
            imbalance_factor = "Minimal change"

        # ── Build action narrative ────────────────────────────────────────
        action_parts = []
        for asset, delta in sorted(buys, key=lambda x: -x[1]):
            if abs(delta) > self.MILD_ACTION:
                action_parts.append(f"**INCREASE** {asset} by {delta:+.1%}")
        for asset, delta in sorted(sells, key=lambda x: x[1]):
            if abs(delta) > self.MILD_ACTION:
                action_parts.append(f"**REDUCE** {asset} by {delta:+.1%}")

        action_narrative = (
            "The agent is choosing to: " + " · ".join(action_parts) + "."
            if action_parts
            else "The agent is maintaining its current allocation with minimal change."
        )

        reward_note = (
            f"This step yielded a reward of {reward:+.5f} "
            f"(raw return {raw_return:+.3%}, risk deduction {risk_penalty:.5f})."
        )

        # ── Assemble explanation ──────────────────────────────────────────
        explanation = (
            f"**Decision Summary**\n"
            f"{action_narrative}\n\n"
            f"**Market Context**\n"
            f"🌍 Regime: {regime} market phase. {regime_signal}\n"
            f"📊 RSI: {rsi_signal}\n"
            f"📈 MACD: {macd_signal}\n"
            f"🌊 Volatility: {vol_signal}\n"
            f"📉 Drawdown: {dd_signal}\n"
            f"⚖️ Portfolio: {imbalance_signal}\n\n"
            f"**Outcome**\n"
            f"{reward_note}\n"
            f"Portfolio is at ${portfolio_value:,.0f} "
            f"({'above' if portfolio_value >= initial_value else 'below'} initial investment)."
        )

        decision_factors = {
            "regime": regime,
            "rsi": rsi_factor,
            "macd": macd_factor,
            "volatility": vol_factor,
            "drawdown": dd_factor,
            "portfolio_imbalance": imbalance_factor,
            "action_summary": action_parts,
        }

        return explanation, decision_factors


# ─────────────────────────────────────────────────────────────────────────────
# Output Layer
# ─────────────────────────────────────────────────────────────────────────────

class OutputLayer:
    """
    Central output and transparency layer for the RL portfolio system.

    Responsibilities:
    1. Log every step to structured in-memory history
    2. Attach human-readable explanations to every action
    3. Provide real-time access to latest decision and portfolio state
    4. Generate episode summaries and JSON exports for dashboard/API consumption

    Parameters
    ----------
    tickers        : list of asset ticker names (excluding cash)
    initial_value  : starting portfolio value (for gain/loss tracking)
    """

    def __init__(self, tickers: list[str], initial_value: float = 100_000.0):
        self.tickers = tickers
        self.initial_value = initial_value
        self._history: list[StepRecord] = []
        self._explainer = ExplainabilityEngine()
        self._peak_value = initial_value

    # ------------------------------------------------------------------
    # Core Logging
    # ------------------------------------------------------------------

    def log_step(
        self,
        episode: int,
        step: int,
        state_features: dict,
        raw_action: list[float] | np.ndarray,
        constrained_weights: list[float] | np.ndarray,
        old_weights: list[float] | np.ndarray,
        reward: float,
        portfolio_value: float,
        raw_return: float = 0.0,
        risk_penalty: float = 0.0,
        metadata: dict | None = None,
    ) -> StepRecord:
        """
        Log a single RL step, generate an explanation, and store the record.

        Parameters
        ----------
        episode             : episode index
        step                : step index within the episode
        state_features      : dict with keys: rsi_mean, macd_signals (list), regime, volatility
        raw_action          : raw portfolio weights from the agent (pre-constraint)
        constrained_weights : final weights after decision engine constraints
        old_weights         : portfolio weights from the previous step
        reward              : scalar reward received
        portfolio_value     : current dollar value of the portfolio
        raw_return          : pre-penalty return (optional)
        risk_penalty        : total risk penalty subtracted (optional)
        metadata            : any extra key-value pairs to store

        Returns
        -------
        StepRecord — the logged record (also appended to internal history)
        """
        raw_action = np.asarray(raw_action, dtype=np.float64)
        new_w = np.asarray(constrained_weights, dtype=np.float64)
        old_w = np.asarray(old_weights, dtype=np.float64)

        # Update peak
        self._peak_value = max(self._peak_value, portfolio_value)
        drawdown = max(0.0, (self._peak_value - portfolio_value) / (self._peak_value + 1e-9))

        # Action labels
        deltas = new_w - old_w
        all_tickers = self.tickers + ["Cash"]
        action_labels = []
        for delta in deltas:
            if delta > 0.02:
                action_labels.append("BUY")
            elif delta < -0.02:
                action_labels.append("SELL")
            else:
                action_labels.append("HOLD")

        # State features extraction
        rsi_mean = float(state_features.get("rsi_mean", 50.0))
        macd_signals = state_features.get("macd_signals", [])
        if isinstance(macd_signals, (list, np.ndarray)):
            macd_bullish_count = int(np.sum(np.asarray(macd_signals) > 0))
        else:
            macd_bullish_count = 0
        regime = str(state_features.get("regime", "Sideways"))
        volatility = float(state_features.get("volatility", 0.15))

        # Generate explanation
        explanation, decision_factors = self._explainer.generate(
            tickers=self.tickers,
            old_weights=old_w.tolist(),
            new_weights=new_w.tolist(),
            action_labels=action_labels,
            rsi_mean=rsi_mean,
            macd_bullish_count=macd_bullish_count,
            n_assets=len(self.tickers),
            regime=regime,
            volatility=volatility,
            reward=reward,
            raw_return=raw_return,
            risk_penalty=risk_penalty,
            portfolio_value=portfolio_value,
            initial_value=self.initial_value,
            peak_value=self._peak_value,
            drawdown=drawdown,
        )

        record = StepRecord(
            episode=episode,
            step=step,
            timestamp=datetime.utcnow().isoformat(timespec="seconds") + "Z",
            regime=regime,
            rsi_mean=rsi_mean,
            macd_bullish_count=macd_bullish_count,
            volatility=volatility,
            raw_action=raw_action.tolist(),
            constrained_weights=new_w.tolist(),
            old_weights=old_w.tolist(),
            action_labels=action_labels,
            action_magnitudes=[round(abs(float(d)), 4) for d in deltas],
            reward=float(reward),
            raw_return=float(raw_return),
            risk_penalty=float(risk_penalty),
            portfolio_value=float(portfolio_value),
            peak_value=float(self._peak_value),
            drawdown=float(drawdown),
            explanation=explanation,
            decision_factors=decision_factors,
            tickers=all_tickers,
            metadata=metadata or {},
        )

        self._history.append(record)
        return record

    # ------------------------------------------------------------------
    # Access
    # ------------------------------------------------------------------

    def get_latest(self) -> StepRecord | None:
        """Return the most recent logged step record."""
        return self._history[-1] if self._history else None

    def get_history(self) -> list[StepRecord]:
        """Return the full step history for the current episode."""
        return list(self._history)

    def get_history_df(self) -> pd.DataFrame:
        """
        Return step history as a flat DataFrame for display and analysis.
        Each row = one step. Nested dicts are JSON-stringified for readability.
        """
        if not self._history:
            return pd.DataFrame()

        rows = []
        for r in self._history:
            row = {
                "Episode": r.episode,
                "Step": r.step,
                "Timestamp": r.timestamp,
                "Regime": r.regime,
                "RSI (avg)": round(r.rsi_mean, 1),
                "MACD Bullish": r.macd_bullish_count,
                "Volatility": f"{r.volatility:.2%}",
                "Reward": round(r.reward, 6),
                "Raw Return": f"{r.raw_return:.3%}",
                "Risk Penalty": round(r.risk_penalty, 6),
                "Portfolio Value": round(r.portfolio_value, 2),
                "Drawdown": f"{r.drawdown:.2%}",
                "Peak Value": round(r.peak_value, 2),
            }
            for i, ticker in enumerate(r.tickers):
                row[f"W: {ticker}"] = f"{r.constrained_weights[i]:.1%}" if i < len(r.constrained_weights) else "N/A"
                row[f"Action: {ticker}"] = r.action_labels[i] if i < len(r.action_labels) else "N/A"
            rows.append(row)

        return pd.DataFrame(rows)

    def get_current_portfolio_state(self) -> dict:
        """
        Return the current portfolio state as a structured dict.
        Suitable for real-time display or API serialisation.
        """
        latest = self.get_latest()
        if latest is None:
            return {
                "portfolio_value": self.initial_value,
                "drawdown": 0.0,
                "regime": "Unknown",
                "weights": {},
                "last_action": {},
            }
        return {
            "portfolio_value": latest.portfolio_value,
            "peak_value": latest.peak_value,
            "drawdown": latest.drawdown,
            "regime": latest.regime,
            "rsi_mean": latest.rsi_mean,
            "volatility": latest.volatility,
            "weights": dict(zip(latest.tickers, latest.constrained_weights)),
            "last_action": dict(zip(latest.tickers, latest.action_labels)),
            "last_reward": latest.reward,
            "last_explanation": latest.explanation,
            "last_step": latest.step,
            "last_episode": latest.episode,
        }

    # ------------------------------------------------------------------
    # Summaries
    # ------------------------------------------------------------------

    def get_episode_summary(self) -> dict:
        """
        Aggregate metrics for the logged episode.

        Returns
        -------
        dict: total_reward, final_portfolio_value, n_steps,
              avg_drawdown, max_drawdown, total_return, n_buys, n_sells, n_holds
        """
        if not self._history:
            return {}

        portfolio_values = [r.portfolio_value for r in self._history]
        rewards = [r.reward for r in self._history]
        drawdowns = [r.drawdown for r in self._history]

        # Count action types
        all_labels = [lbl for r in self._history for lbl in r.action_labels]
        n_buys = all_labels.count("BUY")
        n_sells = all_labels.count("SELL")
        n_holds = all_labels.count("HOLD")

        return {
            "total_reward": round(float(np.sum(rewards)), 6),
            "final_portfolio_value": round(portfolio_values[-1], 2),
            "initial_portfolio_value": round(self.initial_value, 2),
            "total_return": round((portfolio_values[-1] - self.initial_value) / self.initial_value, 6),
            "n_steps": len(self._history),
            "avg_drawdown": round(float(np.mean(drawdowns)), 6),
            "max_drawdown": round(float(np.max(drawdowns)), 6),
            "n_buys": n_buys,
            "n_sells": n_sells,
            "n_holds": n_holds,
            "dominant_regime": max(
                set(r.regime for r in self._history),
                key=lambda x: sum(r.regime == x for r in self._history)
            ),
        }

    def get_portfolio_value_series(self) -> list[float]:
        """Return portfolio value at each step as a list (for plotting)."""
        return [r.portfolio_value for r in self._history]

    def get_reward_series(self) -> list[float]:
        """Return reward at each step as a list."""
        return [r.reward for r in self._history]

    def get_drawdown_series(self) -> list[float]:
        """Return drawdown at each step as a list."""
        return [r.drawdown for r in self._history]

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    def to_json(self, indent: int = 2) -> str:
        """
        Serialise the full step history to a JSON string.
        Compatible with REST API responses and frontend dashboards.
        """
        data = {
            "tickers": self.tickers,
            "initial_value": self.initial_value,
            "episode_summary": self.get_episode_summary(),
            "current_state": self.get_current_portfolio_state(),
            "history": [asdict(r) for r in self._history],
        }
        return json.dumps(data, indent=indent, default=str)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def reset(self, episode: int | None = None) -> None:
        """Clear history for a new episode. Peak value resets to initial."""
        self._history = []
        self._peak_value = self.initial_value

    def __len__(self) -> int:
        return len(self._history)

    def __repr__(self) -> str:
        return (
            f"OutputLayer(tickers={self.tickers}, "
            f"steps={len(self._history)}, "
            f"latest_value={self.get_latest().portfolio_value if self._history else 'N/A'})"
        )
